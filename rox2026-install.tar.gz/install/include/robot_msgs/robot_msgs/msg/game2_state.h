// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_msgs:msg/Game2State.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_MSGS__MSG__GAME2_STATE_H_
#define ROBOT_MSGS__MSG__GAME2_STATE_H_

#include "robot_msgs/msg/detail/game2_state__struct.h"
#include "robot_msgs/msg/detail/game2_state__functions.h"
#include "robot_msgs/msg/detail/game2_state__type_support.h"

#endif  // ROBOT_MSGS__MSG__GAME2_STATE_H_
