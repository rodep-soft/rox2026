// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_msgs:msg/ArmPosition.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_MSGS__MSG__ARM_POSITION_H_
#define ROBOT_MSGS__MSG__ARM_POSITION_H_

#include "robot_msgs/msg/detail/arm_position__struct.h"
#include "robot_msgs/msg/detail/arm_position__functions.h"
#include "robot_msgs/msg/detail/arm_position__type_support.h"

#endif  // ROBOT_MSGS__MSG__ARM_POSITION_H_
