// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROBOT_MSGS__MSG__SHOT_CYCLE_STATE_HPP_
#define ROBOT_MSGS__MSG__SHOT_CYCLE_STATE_HPP_

#include "robot_msgs/msg/detail/shot_cycle_state__struct.hpp"
#include "robot_msgs/msg/detail/shot_cycle_state__builder.hpp"
#include "robot_msgs/msg/detail/shot_cycle_state__traits.hpp"
#include "robot_msgs/msg/detail/shot_cycle_state__type_support.hpp"

#endif  // ROBOT_MSGS__MSG__SHOT_CYCLE_STATE_HPP_
