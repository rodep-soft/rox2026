// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROBOT_MSGS__MSG__BELT_STATUS_HPP_
#define ROBOT_MSGS__MSG__BELT_STATUS_HPP_

#include "robot_msgs/msg/detail/belt_status__struct.hpp"
#include "robot_msgs/msg/detail/belt_status__builder.hpp"
#include "robot_msgs/msg/detail/belt_status__traits.hpp"
#include "robot_msgs/msg/detail/belt_status__type_support.hpp"

#endif  // ROBOT_MSGS__MSG__BELT_STATUS_HPP_
