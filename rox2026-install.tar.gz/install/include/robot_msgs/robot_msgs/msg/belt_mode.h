// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_msgs:msg/BeltMode.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_MSGS__MSG__BELT_MODE_H_
#define ROBOT_MSGS__MSG__BELT_MODE_H_

#include "robot_msgs/msg/detail/belt_mode__struct.h"
#include "robot_msgs/msg/detail/belt_mode__functions.h"
#include "robot_msgs/msg/detail/belt_mode__type_support.h"

#endif  // ROBOT_MSGS__MSG__BELT_MODE_H_
