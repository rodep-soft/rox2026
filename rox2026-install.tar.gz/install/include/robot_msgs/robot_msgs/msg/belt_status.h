// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_msgs:msg/BeltStatus.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_MSGS__MSG__BELT_STATUS_H_
#define ROBOT_MSGS__MSG__BELT_STATUS_H_

#include "robot_msgs/msg/detail/belt_status__struct.h"
#include "robot_msgs/msg/detail/belt_status__functions.h"
#include "robot_msgs/msg/detail/belt_status__type_support.h"

#endif  // ROBOT_MSGS__MSG__BELT_STATUS_H_
