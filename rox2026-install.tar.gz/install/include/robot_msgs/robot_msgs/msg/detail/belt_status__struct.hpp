// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_msgs:msg/BeltStatus.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_MSGS__MSG__DETAIL__BELT_STATUS__STRUCT_HPP_
#define ROBOT_MSGS__MSG__DETAIL__BELT_STATUS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__robot_msgs__msg__BeltStatus __attribute__((deprecated))
#else
# define DEPRECATED__robot_msgs__msg__BeltStatus __declspec(deprecated)
#endif

namespace robot_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct BeltStatus_
{
  using Type = BeltStatus_<ContainerAllocator>;

  explicit BeltStatus_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->underbelt_target_rpm = 0.0f;
      this->underbelt_measured_rpm = 0.0f;
      this->upperbelt_target_rpm = 0.0f;
      this->upperbelt_measured_rpm = 0.0f;
      this->rpm_difference = 0.0f;
    }
  }

  explicit BeltStatus_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->underbelt_target_rpm = 0.0f;
      this->underbelt_measured_rpm = 0.0f;
      this->upperbelt_target_rpm = 0.0f;
      this->upperbelt_measured_rpm = 0.0f;
      this->rpm_difference = 0.0f;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _underbelt_target_rpm_type =
    float;
  _underbelt_target_rpm_type underbelt_target_rpm;
  using _underbelt_measured_rpm_type =
    float;
  _underbelt_measured_rpm_type underbelt_measured_rpm;
  using _upperbelt_target_rpm_type =
    float;
  _upperbelt_target_rpm_type upperbelt_target_rpm;
  using _upperbelt_measured_rpm_type =
    float;
  _upperbelt_measured_rpm_type upperbelt_measured_rpm;
  using _rpm_difference_type =
    float;
  _rpm_difference_type rpm_difference;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__underbelt_target_rpm(
    const float & _arg)
  {
    this->underbelt_target_rpm = _arg;
    return *this;
  }
  Type & set__underbelt_measured_rpm(
    const float & _arg)
  {
    this->underbelt_measured_rpm = _arg;
    return *this;
  }
  Type & set__upperbelt_target_rpm(
    const float & _arg)
  {
    this->upperbelt_target_rpm = _arg;
    return *this;
  }
  Type & set__upperbelt_measured_rpm(
    const float & _arg)
  {
    this->upperbelt_measured_rpm = _arg;
    return *this;
  }
  Type & set__rpm_difference(
    const float & _arg)
  {
    this->rpm_difference = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_msgs::msg::BeltStatus_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_msgs::msg::BeltStatus_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_msgs::msg::BeltStatus_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_msgs::msg::BeltStatus_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_msgs::msg::BeltStatus_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_msgs::msg::BeltStatus_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_msgs::msg::BeltStatus_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_msgs::msg::BeltStatus_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_msgs::msg::BeltStatus_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_msgs::msg::BeltStatus_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_msgs__msg__BeltStatus
    std::shared_ptr<robot_msgs::msg::BeltStatus_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_msgs__msg__BeltStatus
    std::shared_ptr<robot_msgs::msg::BeltStatus_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const BeltStatus_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->underbelt_target_rpm != other.underbelt_target_rpm) {
      return false;
    }
    if (this->underbelt_measured_rpm != other.underbelt_measured_rpm) {
      return false;
    }
    if (this->upperbelt_target_rpm != other.upperbelt_target_rpm) {
      return false;
    }
    if (this->upperbelt_measured_rpm != other.upperbelt_measured_rpm) {
      return false;
    }
    if (this->rpm_difference != other.rpm_difference) {
      return false;
    }
    return true;
  }
  bool operator!=(const BeltStatus_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct BeltStatus_

// alias to use template instance with default allocator
using BeltStatus =
  robot_msgs::msg::BeltStatus_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace robot_msgs

#endif  // ROBOT_MSGS__MSG__DETAIL__BELT_STATUS__STRUCT_HPP_
