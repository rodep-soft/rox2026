﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_msgs:msg/ArmPosition.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_MSGS__MSG__DETAIL__ARM_POSITION__STRUCT_H_
#define ROBOT_MSGS__MSG__DETAIL__ARM_POSITION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'DRIBBLE'.
enum
{
  robot_msgs__msg__ArmPosition__DRIBBLE = 0
};

/// Constant 'OPEN'.
enum
{
  robot_msgs__msg__ArmPosition__OPEN = 1
};

/// Constant 'FEED'.
enum
{
  robot_msgs__msg__ArmPosition__FEED = 2
};

/// Constant 'RECEIVE'.
enum
{
  robot_msgs__msg__ArmPosition__RECEIVE = 3
};

/// Struct defined in msg/ArmPosition in the package robot_msgs.
/**
  * ドリブルアーム姿勢定義
 */
typedef struct robot_msgs__msg__ArmPosition
{
  uint8_t position;
} robot_msgs__msg__ArmPosition;

// Struct for a sequence of robot_msgs__msg__ArmPosition.
typedef struct robot_msgs__msg__ArmPosition__Sequence
{
  robot_msgs__msg__ArmPosition * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_msgs__msg__ArmPosition__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_MSGS__MSG__DETAIL__ARM_POSITION__STRUCT_H_
