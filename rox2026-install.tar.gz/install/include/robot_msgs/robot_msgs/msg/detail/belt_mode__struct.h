﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_msgs:msg/BeltMode.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_MSGS__MSG__DETAIL__BELT_MODE__STRUCT_H_
#define ROBOT_MSGS__MSG__DETAIL__BELT_MODE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'STOP'.
enum
{
  robot_msgs__msg__BeltMode__STOP = 0
};

/// Constant 'LEVEL_1'.
enum
{
  robot_msgs__msg__BeltMode__LEVEL_1 = 1
};

/// Constant 'LEVEL_2'.
enum
{
  robot_msgs__msg__BeltMode__LEVEL_2 = 2
};

/// Constant 'LEVEL_3'.
enum
{
  robot_msgs__msg__BeltMode__LEVEL_3 = 3
};

/// Constant 'LEVEL_4'.
enum
{
  robot_msgs__msg__BeltMode__LEVEL_4 = 4
};

/// Struct defined in msg/BeltMode in the package robot_msgs.
/**
  * ベルト駆動モード定義
 */
typedef struct robot_msgs__msg__BeltMode
{
  uint8_t mode;
} robot_msgs__msg__BeltMode;

// Struct for a sequence of robot_msgs__msg__BeltMode.
typedef struct robot_msgs__msg__BeltMode__Sequence
{
  robot_msgs__msg__BeltMode * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_msgs__msg__BeltMode__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_MSGS__MSG__DETAIL__BELT_MODE__STRUCT_H_
