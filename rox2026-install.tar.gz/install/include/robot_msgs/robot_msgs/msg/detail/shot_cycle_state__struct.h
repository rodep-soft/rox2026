﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_msgs:msg/ShotCycleState.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_MSGS__MSG__DETAIL__SHOT_CYCLE_STATE__STRUCT_H_
#define ROBOT_MSGS__MSG__DETAIL__SHOT_CYCLE_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'IDLE'.
enum
{
  robot_msgs__msg__ShotCycleState__IDLE = 0
};

/// Constant 'BELT_SPINUP'.
enum
{
  robot_msgs__msg__ShotCycleState__BELT_SPINUP = 1
};

/// Constant 'OPENING'.
enum
{
  robot_msgs__msg__ShotCycleState__OPENING = 2
};

/// Constant 'FEEDING'.
enum
{
  robot_msgs__msg__ShotCycleState__FEEDING = 3
};

/// Constant 'RETURNING'.
enum
{
  robot_msgs__msg__ShotCycleState__RETURNING = 4
};

/// Struct defined in msg/ShotCycleState in the package robot_msgs.
/**
  * 自動シュートサイクル進行状態定義
 */
typedef struct robot_msgs__msg__ShotCycleState
{
  uint8_t state;
} robot_msgs__msg__ShotCycleState;

// Struct for a sequence of robot_msgs__msg__ShotCycleState.
typedef struct robot_msgs__msg__ShotCycleState__Sequence
{
  robot_msgs__msg__ShotCycleState * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_msgs__msg__ShotCycleState__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_MSGS__MSG__DETAIL__SHOT_CYCLE_STATE__STRUCT_H_
