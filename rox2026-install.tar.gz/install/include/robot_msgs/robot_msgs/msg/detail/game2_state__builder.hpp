// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_msgs:msg/Game2State.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_MSGS__MSG__DETAIL__GAME2_STATE__BUILDER_HPP_
#define ROBOT_MSGS__MSG__DETAIL__GAME2_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_msgs/msg/detail/game2_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_msgs
{

namespace msg
{

namespace builder
{

class Init_Game2State_state
{
public:
  Init_Game2State_state()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::robot_msgs::msg::Game2State state(::robot_msgs::msg::Game2State::_state_type arg)
  {
    msg_.state = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_msgs::msg::Game2State msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_msgs::msg::Game2State>()
{
  return robot_msgs::msg::builder::Init_Game2State_state();
}

}  // namespace robot_msgs

#endif  // ROBOT_MSGS__MSG__DETAIL__GAME2_STATE__BUILDER_HPP_
