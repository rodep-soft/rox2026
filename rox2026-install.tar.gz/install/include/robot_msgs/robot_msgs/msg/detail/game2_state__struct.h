﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_msgs:msg/Game2State.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_MSGS__MSG__DETAIL__GAME2_STATE__STRUCT_H_
#define ROBOT_MSGS__MSG__DETAIL__GAME2_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'STANDBY'.
enum
{
  robot_msgs__msg__Game2State__STANDBY = 0
};

/// Constant 'SEARCHING'.
enum
{
  robot_msgs__msg__Game2State__SEARCHING = 1
};

/// Constant 'ALIGNING'.
enum
{
  robot_msgs__msg__Game2State__ALIGNING = 2
};

/// Constant 'PREPARING_SHOOT'.
enum
{
  robot_msgs__msg__Game2State__PREPARING_SHOOT = 3
};

/// Constant 'SHOOTING'.
enum
{
  robot_msgs__msg__Game2State__SHOOTING = 4
};

/// Constant 'WAITING_RESULT'.
enum
{
  robot_msgs__msg__Game2State__WAITING_RESULT = 5
};

/// Constant 'COMPLETED'.
enum
{
  robot_msgs__msg__Game2State__COMPLETED = 6
};

/// Struct defined in msg/Game2State in the package robot_msgs.
/**
  * Game2 パネル戦術自動射出シーケンス状態
 */
typedef struct robot_msgs__msg__Game2State
{
  uint8_t state;
} robot_msgs__msg__Game2State;

// Struct for a sequence of robot_msgs__msg__Game2State.
typedef struct robot_msgs__msg__Game2State__Sequence
{
  robot_msgs__msg__Game2State * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_msgs__msg__Game2State__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_MSGS__MSG__DETAIL__GAME2_STATE__STRUCT_H_
