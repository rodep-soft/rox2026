// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_msgs:msg/ArmPosition.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_MSGS__MSG__DETAIL__ARM_POSITION__STRUCT_HPP_
#define ROBOT_MSGS__MSG__DETAIL__ARM_POSITION__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__robot_msgs__msg__ArmPosition __attribute__((deprecated))
#else
# define DEPRECATED__robot_msgs__msg__ArmPosition __declspec(deprecated)
#endif

namespace robot_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ArmPosition_
{
  using Type = ArmPosition_<ContainerAllocator>;

  explicit ArmPosition_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->position = 0;
    }
  }

  explicit ArmPosition_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->position = 0;
    }
  }

  // field types and members
  using _position_type =
    uint8_t;
  _position_type position;

  // setters for named parameter idiom
  Type & set__position(
    const uint8_t & _arg)
  {
    this->position = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t DRIBBLE =
    0u;
  static constexpr uint8_t OPEN =
    1u;
  static constexpr uint8_t FEED =
    2u;
  static constexpr uint8_t RECEIVE =
    3u;

  // pointer types
  using RawPtr =
    robot_msgs::msg::ArmPosition_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_msgs::msg::ArmPosition_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_msgs::msg::ArmPosition_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_msgs::msg::ArmPosition_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_msgs::msg::ArmPosition_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_msgs::msg::ArmPosition_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_msgs::msg::ArmPosition_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_msgs::msg::ArmPosition_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_msgs::msg::ArmPosition_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_msgs::msg::ArmPosition_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_msgs__msg__ArmPosition
    std::shared_ptr<robot_msgs::msg::ArmPosition_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_msgs__msg__ArmPosition
    std::shared_ptr<robot_msgs::msg::ArmPosition_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ArmPosition_ & other) const
  {
    if (this->position != other.position) {
      return false;
    }
    return true;
  }
  bool operator!=(const ArmPosition_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ArmPosition_

// alias to use template instance with default allocator
using ArmPosition =
  robot_msgs::msg::ArmPosition_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ArmPosition_<ContainerAllocator>::DRIBBLE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ArmPosition_<ContainerAllocator>::OPEN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ArmPosition_<ContainerAllocator>::FEED;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ArmPosition_<ContainerAllocator>::RECEIVE;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace robot_msgs

#endif  // ROBOT_MSGS__MSG__DETAIL__ARM_POSITION__STRUCT_HPP_
