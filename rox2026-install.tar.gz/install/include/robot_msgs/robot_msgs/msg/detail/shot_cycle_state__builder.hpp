// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_msgs:msg/ShotCycleState.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_MSGS__MSG__DETAIL__SHOT_CYCLE_STATE__BUILDER_HPP_
#define ROBOT_MSGS__MSG__DETAIL__SHOT_CYCLE_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_msgs/msg/detail/shot_cycle_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_msgs
{

namespace msg
{

namespace builder
{

class Init_ShotCycleState_state
{
public:
  Init_ShotCycleState_state()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::robot_msgs::msg::ShotCycleState state(::robot_msgs::msg::ShotCycleState::_state_type arg)
  {
    msg_.state = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_msgs::msg::ShotCycleState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_msgs::msg::ShotCycleState>()
{
  return robot_msgs::msg::builder::Init_ShotCycleState_state();
}

}  // namespace robot_msgs

#endif  // ROBOT_MSGS__MSG__DETAIL__SHOT_CYCLE_STATE__BUILDER_HPP_
