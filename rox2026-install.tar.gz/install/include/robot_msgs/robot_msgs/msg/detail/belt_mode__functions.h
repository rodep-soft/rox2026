// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from robot_msgs:msg/BeltMode.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_MSGS__MSG__DETAIL__BELT_MODE__FUNCTIONS_H_
#define ROBOT_MSGS__MSG__DETAIL__BELT_MODE__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "robot_msgs/msg/rosidl_generator_c__visibility_control.h"

#include "robot_msgs/msg/detail/belt_mode__struct.h"

/// Initialize msg/BeltMode message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * robot_msgs__msg__BeltMode
 * )) before or use
 * robot_msgs__msg__BeltMode__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_robot_msgs
bool
robot_msgs__msg__BeltMode__init(robot_msgs__msg__BeltMode * msg);

/// Finalize msg/BeltMode message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_robot_msgs
void
robot_msgs__msg__BeltMode__fini(robot_msgs__msg__BeltMode * msg);

/// Create msg/BeltMode message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * robot_msgs__msg__BeltMode__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_robot_msgs
robot_msgs__msg__BeltMode *
robot_msgs__msg__BeltMode__create();

/// Destroy msg/BeltMode message.
/**
 * It calls
 * robot_msgs__msg__BeltMode__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_robot_msgs
void
robot_msgs__msg__BeltMode__destroy(robot_msgs__msg__BeltMode * msg);

/// Check for msg/BeltMode message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_robot_msgs
bool
robot_msgs__msg__BeltMode__are_equal(const robot_msgs__msg__BeltMode * lhs, const robot_msgs__msg__BeltMode * rhs);

/// Copy a msg/BeltMode message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_robot_msgs
bool
robot_msgs__msg__BeltMode__copy(
  const robot_msgs__msg__BeltMode * input,
  robot_msgs__msg__BeltMode * output);

/// Initialize array of msg/BeltMode messages.
/**
 * It allocates the memory for the number of elements and calls
 * robot_msgs__msg__BeltMode__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_robot_msgs
bool
robot_msgs__msg__BeltMode__Sequence__init(robot_msgs__msg__BeltMode__Sequence * array, size_t size);

/// Finalize array of msg/BeltMode messages.
/**
 * It calls
 * robot_msgs__msg__BeltMode__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_robot_msgs
void
robot_msgs__msg__BeltMode__Sequence__fini(robot_msgs__msg__BeltMode__Sequence * array);

/// Create array of msg/BeltMode messages.
/**
 * It allocates the memory for the array and calls
 * robot_msgs__msg__BeltMode__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_robot_msgs
robot_msgs__msg__BeltMode__Sequence *
robot_msgs__msg__BeltMode__Sequence__create(size_t size);

/// Destroy array of msg/BeltMode messages.
/**
 * It calls
 * robot_msgs__msg__BeltMode__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_robot_msgs
void
robot_msgs__msg__BeltMode__Sequence__destroy(robot_msgs__msg__BeltMode__Sequence * array);

/// Check for msg/BeltMode message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_robot_msgs
bool
robot_msgs__msg__BeltMode__Sequence__are_equal(const robot_msgs__msg__BeltMode__Sequence * lhs, const robot_msgs__msg__BeltMode__Sequence * rhs);

/// Copy an array of msg/BeltMode messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_robot_msgs
bool
robot_msgs__msg__BeltMode__Sequence__copy(
  const robot_msgs__msg__BeltMode__Sequence * input,
  robot_msgs__msg__BeltMode__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_MSGS__MSG__DETAIL__BELT_MODE__FUNCTIONS_H_
