// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_msgs:msg/BeltStatus.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_MSGS__MSG__DETAIL__BELT_STATUS__BUILDER_HPP_
#define ROBOT_MSGS__MSG__DETAIL__BELT_STATUS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_msgs/msg/detail/belt_status__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_msgs
{

namespace msg
{

namespace builder
{

class Init_BeltStatus_rpm_difference
{
public:
  explicit Init_BeltStatus_rpm_difference(::robot_msgs::msg::BeltStatus & msg)
  : msg_(msg)
  {}
  ::robot_msgs::msg::BeltStatus rpm_difference(::robot_msgs::msg::BeltStatus::_rpm_difference_type arg)
  {
    msg_.rpm_difference = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_msgs::msg::BeltStatus msg_;
};

class Init_BeltStatus_upperbelt_measured_rpm
{
public:
  explicit Init_BeltStatus_upperbelt_measured_rpm(::robot_msgs::msg::BeltStatus & msg)
  : msg_(msg)
  {}
  Init_BeltStatus_rpm_difference upperbelt_measured_rpm(::robot_msgs::msg::BeltStatus::_upperbelt_measured_rpm_type arg)
  {
    msg_.upperbelt_measured_rpm = std::move(arg);
    return Init_BeltStatus_rpm_difference(msg_);
  }

private:
  ::robot_msgs::msg::BeltStatus msg_;
};

class Init_BeltStatus_upperbelt_target_rpm
{
public:
  explicit Init_BeltStatus_upperbelt_target_rpm(::robot_msgs::msg::BeltStatus & msg)
  : msg_(msg)
  {}
  Init_BeltStatus_upperbelt_measured_rpm upperbelt_target_rpm(::robot_msgs::msg::BeltStatus::_upperbelt_target_rpm_type arg)
  {
    msg_.upperbelt_target_rpm = std::move(arg);
    return Init_BeltStatus_upperbelt_measured_rpm(msg_);
  }

private:
  ::robot_msgs::msg::BeltStatus msg_;
};

class Init_BeltStatus_underbelt_measured_rpm
{
public:
  explicit Init_BeltStatus_underbelt_measured_rpm(::robot_msgs::msg::BeltStatus & msg)
  : msg_(msg)
  {}
  Init_BeltStatus_upperbelt_target_rpm underbelt_measured_rpm(::robot_msgs::msg::BeltStatus::_underbelt_measured_rpm_type arg)
  {
    msg_.underbelt_measured_rpm = std::move(arg);
    return Init_BeltStatus_upperbelt_target_rpm(msg_);
  }

private:
  ::robot_msgs::msg::BeltStatus msg_;
};

class Init_BeltStatus_underbelt_target_rpm
{
public:
  explicit Init_BeltStatus_underbelt_target_rpm(::robot_msgs::msg::BeltStatus & msg)
  : msg_(msg)
  {}
  Init_BeltStatus_underbelt_measured_rpm underbelt_target_rpm(::robot_msgs::msg::BeltStatus::_underbelt_target_rpm_type arg)
  {
    msg_.underbelt_target_rpm = std::move(arg);
    return Init_BeltStatus_underbelt_measured_rpm(msg_);
  }

private:
  ::robot_msgs::msg::BeltStatus msg_;
};

class Init_BeltStatus_header
{
public:
  Init_BeltStatus_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_BeltStatus_underbelt_target_rpm header(::robot_msgs::msg::BeltStatus::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_BeltStatus_underbelt_target_rpm(msg_);
  }

private:
  ::robot_msgs::msg::BeltStatus msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_msgs::msg::BeltStatus>()
{
  return robot_msgs::msg::builder::Init_BeltStatus_header();
}

}  // namespace robot_msgs

#endif  // ROBOT_MSGS__MSG__DETAIL__BELT_STATUS__BUILDER_HPP_
