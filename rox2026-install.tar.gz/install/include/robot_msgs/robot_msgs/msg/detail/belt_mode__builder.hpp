// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_msgs:msg/BeltMode.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_MSGS__MSG__DETAIL__BELT_MODE__BUILDER_HPP_
#define ROBOT_MSGS__MSG__DETAIL__BELT_MODE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_msgs/msg/detail/belt_mode__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_msgs
{

namespace msg
{

namespace builder
{

class Init_BeltMode_mode
{
public:
  Init_BeltMode_mode()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::robot_msgs::msg::BeltMode mode(::robot_msgs::msg::BeltMode::_mode_type arg)
  {
    msg_.mode = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_msgs::msg::BeltMode msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_msgs::msg::BeltMode>()
{
  return robot_msgs::msg::builder::Init_BeltMode_mode();
}

}  // namespace robot_msgs

#endif  // ROBOT_MSGS__MSG__DETAIL__BELT_MODE__BUILDER_HPP_
