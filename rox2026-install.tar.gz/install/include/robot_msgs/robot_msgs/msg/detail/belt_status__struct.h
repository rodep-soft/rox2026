﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_msgs:msg/BeltStatus.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_MSGS__MSG__DETAIL__BELT_STATUS__STRUCT_H_
#define ROBOT_MSGS__MSG__DETAIL__BELT_STATUS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/BeltStatus in the package robot_msgs.
/**
  * 上下ベルトのRPM実測・目標状態（定量評価用）
 */
typedef struct robot_msgs__msg__BeltStatus
{
  std_msgs__msg__Header header;
  float underbelt_target_rpm;
  float underbelt_measured_rpm;
  float upperbelt_target_rpm;
  float upperbelt_measured_rpm;
  float rpm_difference;
} robot_msgs__msg__BeltStatus;

// Struct for a sequence of robot_msgs__msg__BeltStatus.
typedef struct robot_msgs__msg__BeltStatus__Sequence
{
  robot_msgs__msg__BeltStatus * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_msgs__msg__BeltStatus__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_MSGS__MSG__DETAIL__BELT_STATUS__STRUCT_H_
