// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_msgs:msg/ArmPosition.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_MSGS__MSG__DETAIL__ARM_POSITION__BUILDER_HPP_
#define ROBOT_MSGS__MSG__DETAIL__ARM_POSITION__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_msgs/msg/detail/arm_position__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_msgs
{

namespace msg
{

namespace builder
{

class Init_ArmPosition_position
{
public:
  Init_ArmPosition_position()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::robot_msgs::msg::ArmPosition position(::robot_msgs::msg::ArmPosition::_position_type arg)
  {
    msg_.position = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_msgs::msg::ArmPosition msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_msgs::msg::ArmPosition>()
{
  return robot_msgs::msg::builder::Init_ArmPosition_position();
}

}  // namespace robot_msgs

#endif  // ROBOT_MSGS__MSG__DETAIL__ARM_POSITION__BUILDER_HPP_
