// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_msgs:msg/BeltMode.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_MSGS__MSG__DETAIL__BELT_MODE__STRUCT_HPP_
#define ROBOT_MSGS__MSG__DETAIL__BELT_MODE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__robot_msgs__msg__BeltMode __attribute__((deprecated))
#else
# define DEPRECATED__robot_msgs__msg__BeltMode __declspec(deprecated)
#endif

namespace robot_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct BeltMode_
{
  using Type = BeltMode_<ContainerAllocator>;

  explicit BeltMode_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->mode = 0;
    }
  }

  explicit BeltMode_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->mode = 0;
    }
  }

  // field types and members
  using _mode_type =
    uint8_t;
  _mode_type mode;

  // setters for named parameter idiom
  Type & set__mode(
    const uint8_t & _arg)
  {
    this->mode = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t STOP =
    0u;
  static constexpr uint8_t LEVEL_1 =
    1u;
  static constexpr uint8_t LEVEL_2 =
    2u;
  static constexpr uint8_t LEVEL_3 =
    3u;
  static constexpr uint8_t LEVEL_4 =
    4u;

  // pointer types
  using RawPtr =
    robot_msgs::msg::BeltMode_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_msgs::msg::BeltMode_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_msgs::msg::BeltMode_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_msgs::msg::BeltMode_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_msgs::msg::BeltMode_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_msgs::msg::BeltMode_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_msgs::msg::BeltMode_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_msgs::msg::BeltMode_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_msgs::msg::BeltMode_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_msgs::msg::BeltMode_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_msgs__msg__BeltMode
    std::shared_ptr<robot_msgs::msg::BeltMode_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_msgs__msg__BeltMode
    std::shared_ptr<robot_msgs::msg::BeltMode_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const BeltMode_ & other) const
  {
    if (this->mode != other.mode) {
      return false;
    }
    return true;
  }
  bool operator!=(const BeltMode_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct BeltMode_

// alias to use template instance with default allocator
using BeltMode =
  robot_msgs::msg::BeltMode_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BeltMode_<ContainerAllocator>::STOP;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BeltMode_<ContainerAllocator>::LEVEL_1;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BeltMode_<ContainerAllocator>::LEVEL_2;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BeltMode_<ContainerAllocator>::LEVEL_3;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BeltMode_<ContainerAllocator>::LEVEL_4;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace robot_msgs

#endif  // ROBOT_MSGS__MSG__DETAIL__BELT_MODE__STRUCT_HPP_
