// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROBOT_MSGS__MSG__GAME2_STATE_HPP_
#define ROBOT_MSGS__MSG__GAME2_STATE_HPP_

#include "robot_msgs/msg/detail/game2_state__struct.hpp"
#include "robot_msgs/msg/detail/game2_state__builder.hpp"
#include "robot_msgs/msg/detail/game2_state__traits.hpp"
#include "robot_msgs/msg/detail/game2_state__type_support.hpp"

#endif  // ROBOT_MSGS__MSG__GAME2_STATE_HPP_
