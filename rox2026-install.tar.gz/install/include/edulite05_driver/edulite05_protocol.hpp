#pragma once

#include <chrono>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <optional>
#include <string>
#include <vector>

#include "can_msgs/msg/frame.hpp"

namespace edulite05_driver
{
constexpr uint8_t HOST_ID = 0xFD;
constexpr uint8_t TYPE_FEEDBACK = 0x02;
constexpr uint8_t TYPE_ENABLE = 0x03;
constexpr uint8_t TYPE_READ = 0x11;
constexpr uint8_t TYPE_FAULT = 0x15;
constexpr uint8_t TYPE_WRITE = 0x12;
constexpr uint8_t RESET_STATUS_MODE = 0x00;
constexpr uint8_t RUN_STATUS_MODE = 0x02;
constexpr uint16_t RUN_MODE = 0x7005;
constexpr uint16_t SPEED_REFERENCE = 0x700A;
constexpr uint16_t POSITION_REFERENCE = 0x7016;
constexpr uint16_t SPEED_LIMIT = 0x7017;
constexpr uint16_t CURRENT_LIMIT = 0x7018;
constexpr uint16_t MECHANICAL_POSITION = 0x7019;
constexpr uint16_t CURRENT_FEEDBACK = 0x701A;
constexpr uint16_t ACCELERATION = 0x7022;
constexpr uint16_t PP_SPEED = 0x7024;
constexpr uint16_t PP_ACCELERATION = 0x7025;
constexpr int MAX_INITIALIZATION_RETRIES = 10;
constexpr auto WRITE_SETTLING_TIME = std::chrono::milliseconds(2);
constexpr auto RESPONSE_TIMEOUT = std::chrono::milliseconds(100);
constexpr auto ERROR_RETRY_PERIOD = std::chrono::milliseconds(200);
constexpr uint32_t CURRENT_FEEDBACK_TIMEOUT_PERIODS = 3;
constexpr float PI = 3.14159265358979323846f;

enum class ControlMode : uint8_t
{
  PROFILE_POSITION = 1,
  VELOCITY = 2,
  CYCLIC_SYNCHRONOUS_POSITION = 5
};

enum class PositionReferenceSource : uint8_t { SET_POSITION_SERVICE, YAML_OFFSET };

enum class PositionReferenceState : uint8_t
{
  NOT_REQUIRED,
  UNAVAILABLE,
  TEMPORARY,
  ESTABLISHED
};

enum class MotorState : uint8_t { OFFLINE, INITIALIZING, READY, ERROR };

struct MotorConfig
{
  std::string name;
  uint16_t logical_id = 0;
  uint8_t can_id = 0;
  ControlMode control_mode = ControlMode::VELOCITY;
  float current_limit = 11.0f;
  float acceleration = 150.0f;
  float speed_limit = 50.0f;
  uint32_t command_period_ms = 10;
  uint32_t target_timeout_ms = 200;
  uint32_t feedback_timeout_ms = 500;
  bool current_feedback_enabled = false;
  uint32_t current_feedback_period_ms = 100;
  bool immediate_state_publish = true;
  PositionReferenceSource position_reference_source =
    PositionReferenceSource::SET_POSITION_SERVICE;
  float position_offset_rad = 0.0f;
  float minimum_position_rad = -1000.0f;
  float maximum_position_rad = 1000.0f;
};

struct MotorFeedback
{
  float position = 0.0f;
  float velocity = 0.0f;
  float torque_nm = 0.0f;
  float current_a = std::numeric_limits<float>::quiet_NaN();
  float temperature = 0.0f;
  uint32_t fault_code = 0;
};

class Protocol
{
public:
  using Clock = std::chrono::steady_clock;
  using TimePoint = Clock::time_point;

  explicit Protocol(const MotorConfig & config);

  const std::string & name() const {return config_.name;}
  uint16_t logical_id() const {return config_.logical_id;}
  uint8_t can_id() const {return config_.can_id;}
  ControlMode control_mode() const {return config_.control_mode;}
  MotorState state() const {return state_;}
  bool position_reference_is_set() const
  {
    return position_reference_state_ == PositionReferenceState::ESTABLISHED;
  }
  const MotorFeedback & feedback() const {return feedback_;}
  int initialization_retry_count() const {return initialization_retry_count_;}
  bool immediate_state_publish() const {return config_.immediate_state_publish;}
  std::string initialization_diagnostic() const;

  /// @brief 目標値を設定
  /// @param target
  /// 目標値（VELOCITYモードでは速度[rad/s]，PP/CSPモードでは位置[rad]）
  void set_target(float target);
  bool set_current_position(float current_position_rad);

  /// @brief 今回の呼び出しで初期化の際に送るフレームの取得
  /// @return 初期化フレーム
  std::optional<can_msgs::msg::Frame> create_initialization_frame(TimePoint current_time);
  /// @brief CANフレームを受信
  /// @param msg 受信したCANフレーム
  /// @return 処理結果 true: 値を受信できた，false: 受信できなかった
  bool receive(const can_msgs::msg::Frame & message);
  /// @brief 目標値の送信が必要かどうか
  /// @return true: 送信が必要，false: 送信不要
  std::optional<can_msgs::msg::Frame> create_target_frame(TimePoint current_time);
  std::optional<can_msgs::msg::Frame> create_current_feedback_frame(
    TimePoint current_time);
  void watchdog(TimePoint current_time);

private:
  enum class InitializationStep
  {
    WRITE_PARAMETER,
    WAIT_AFTER_WRITE,
    READ_PARAMETER,
    WAIT_FOR_READ,
    READ_STARTUP_POSITION,
    WAIT_FOR_STARTUP_POSITION,
    WRITE_STARTUP_HOLD,
    WAIT_AFTER_STARTUP_HOLD_WRITE,
    READ_STARTUP_HOLD,
    WAIT_FOR_STARTUP_HOLD,
    ENABLE,
    WAIT_FOR_ENABLE,
    READY,
    ERROR
  };

  enum class InitializationParameterType : uint8_t { UINT8, FLOAT };

  struct InitializationParameter
  {
    uint16_t index;
    InitializationParameterType type;
    float value;
  };

  bool uses_position_control() const;
  bool position_command_is_allowed() const;
  /// @brief 初期化のリトライ
  void retry_initialization();
  /// @brief モータの初期化からやり直すことを指示
  /// @param clear_target やり直すモータの目標値を破棄するかどうか
  void restart_initialization(bool clear_target);
  /// @brief フィードバックを処理
  /// @param msg 受信したCANフレーム
  void process_feedback(const can_msgs::msg::Frame & message);
  /// @brief パラメータ応答を処理
  /// @param msg 受信したCANフレーム
  bool process_parameter_response(const can_msgs::msg::Frame & message);
  bool process_fault(const can_msgs::msg::Frame & message);
  void enter_fault_state(uint32_t fault_code, TimePoint current_time);
  void invalidate_stale_current(TimePoint current_time);

  static can_msgs::msg::Frame make_base_frame(uint8_t type, uint8_t motor_id);
  static can_msgs::msg::Frame
  make_write_uint8_frame(uint8_t motor_id, uint16_t index, uint8_t value);
  static can_msgs::msg::Frame
  make_write_float_frame(uint8_t motor_id, uint16_t index, float value);
  static can_msgs::msg::Frame make_read_parameter_frame(
    uint8_t motor_id,
    uint16_t index);
  static can_msgs::msg::Frame make_enable_frame(uint8_t motor_id);

  MotorConfig config_;
  MotorFeedback feedback_;
  MotorState state_ = MotorState::INITIALIZING;
  InitializationStep initialization_step_ = InitializationStep::WRITE_PARAMETER;
  std::vector<InitializationParameter> initialization_parameters_;
  std::size_t initialization_parameter_index_ = 0;
  float target_value_ = 0.0f;
  bool has_target_ = false;
  bool feedback_connected_ = false;
  bool motor_enabled_ = false;
  bool startup_run_state_observed_ = false;
  bool motor_was_running_at_startup_ = false;
  int consecutive_non_run_feedback_count_ = 0;
  int initialization_retry_count_ = 0;
  uint32_t detailed_fault_code_ = 0;
  float motor_position_rad_ = 0.0f;
  float last_wrapped_position_rad_ = 0.0f;
  bool motor_position_initialized_ = false;
  bool startup_position_alignment_pending_ = false;
  float logical_position_offset_rad_ = 0.0f;
  float startup_hold_position_rad_ = 0.0f;
  PositionReferenceState position_reference_state_ =
    PositionReferenceState::NOT_REQUIRED;
  TimePoint last_feedback_time_{};
  TimePoint last_request_time_{};
  TimePoint last_target_time_{};
  TimePoint last_command_time_{};
  TimePoint last_current_feedback_request_time_{};
  TimePoint last_current_feedback_time_{};
  TimePoint error_time_{};
};
} // namespace edulite05_driver
