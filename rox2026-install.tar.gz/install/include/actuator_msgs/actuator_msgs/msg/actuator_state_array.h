// generated from rosidl_generator_c/resource/idl.h.em
// with input from actuator_msgs:msg/ActuatorStateArray.idl
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__MSG__ACTUATOR_STATE_ARRAY_H_
#define ACTUATOR_MSGS__MSG__ACTUATOR_STATE_ARRAY_H_

#include "actuator_msgs/msg/detail/actuator_state_array__struct.h"
#include "actuator_msgs/msg/detail/actuator_state_array__functions.h"
#include "actuator_msgs/msg/detail/actuator_state_array__type_support.h"

#endif  // ACTUATOR_MSGS__MSG__ACTUATOR_STATE_ARRAY_H_
