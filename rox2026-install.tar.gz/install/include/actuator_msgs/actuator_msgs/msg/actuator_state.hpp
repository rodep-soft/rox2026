// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__MSG__ACTUATOR_STATE_HPP_
#define ACTUATOR_MSGS__MSG__ACTUATOR_STATE_HPP_

#include "actuator_msgs/msg/detail/actuator_state__struct.hpp"
#include "actuator_msgs/msg/detail/actuator_state__builder.hpp"
#include "actuator_msgs/msg/detail/actuator_state__traits.hpp"
#include "actuator_msgs/msg/detail/actuator_state__type_support.hpp"

#endif  // ACTUATOR_MSGS__MSG__ACTUATOR_STATE_HPP_
