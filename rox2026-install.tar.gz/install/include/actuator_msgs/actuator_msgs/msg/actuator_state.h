// generated from rosidl_generator_c/resource/idl.h.em
// with input from actuator_msgs:msg/ActuatorState.idl
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__MSG__ACTUATOR_STATE_H_
#define ACTUATOR_MSGS__MSG__ACTUATOR_STATE_H_

#include "actuator_msgs/msg/detail/actuator_state__struct.h"
#include "actuator_msgs/msg/detail/actuator_state__functions.h"
#include "actuator_msgs/msg/detail/actuator_state__type_support.h"

#endif  // ACTUATOR_MSGS__MSG__ACTUATOR_STATE_H_
