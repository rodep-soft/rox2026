// generated from rosidl_generator_c/resource/idl.h.em
// with input from actuator_msgs:msg/ActuatorTarget.idl
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__MSG__ACTUATOR_TARGET_H_
#define ACTUATOR_MSGS__MSG__ACTUATOR_TARGET_H_

#include "actuator_msgs/msg/detail/actuator_target__struct.h"
#include "actuator_msgs/msg/detail/actuator_target__functions.h"
#include "actuator_msgs/msg/detail/actuator_target__type_support.h"

#endif  // ACTUATOR_MSGS__MSG__ACTUATOR_TARGET_H_
