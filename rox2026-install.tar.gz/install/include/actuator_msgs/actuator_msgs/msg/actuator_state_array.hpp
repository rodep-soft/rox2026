// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__MSG__ACTUATOR_STATE_ARRAY_HPP_
#define ACTUATOR_MSGS__MSG__ACTUATOR_STATE_ARRAY_HPP_

#include "actuator_msgs/msg/detail/actuator_state_array__struct.hpp"
#include "actuator_msgs/msg/detail/actuator_state_array__builder.hpp"
#include "actuator_msgs/msg/detail/actuator_state_array__traits.hpp"
#include "actuator_msgs/msg/detail/actuator_state_array__type_support.hpp"

#endif  // ACTUATOR_MSGS__MSG__ACTUATOR_STATE_ARRAY_HPP_
