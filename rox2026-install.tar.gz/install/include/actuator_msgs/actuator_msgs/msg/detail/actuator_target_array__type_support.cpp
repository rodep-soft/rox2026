// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from actuator_msgs:msg/ActuatorTargetArray.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "actuator_msgs/msg/detail/actuator_target_array__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace actuator_msgs
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void ActuatorTargetArray_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) actuator_msgs::msg::ActuatorTargetArray(_init);
}

void ActuatorTargetArray_fini_function(void * message_memory)
{
  auto typed_message = static_cast<actuator_msgs::msg::ActuatorTargetArray *>(message_memory);
  typed_message->~ActuatorTargetArray();
}

size_t size_function__ActuatorTargetArray__actuators(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<actuator_msgs::msg::ActuatorTarget> *>(untyped_member);
  return member->size();
}

const void * get_const_function__ActuatorTargetArray__actuators(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<actuator_msgs::msg::ActuatorTarget> *>(untyped_member);
  return &member[index];
}

void * get_function__ActuatorTargetArray__actuators(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<actuator_msgs::msg::ActuatorTarget> *>(untyped_member);
  return &member[index];
}

void fetch_function__ActuatorTargetArray__actuators(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const actuator_msgs::msg::ActuatorTarget *>(
    get_const_function__ActuatorTargetArray__actuators(untyped_member, index));
  auto & value = *reinterpret_cast<actuator_msgs::msg::ActuatorTarget *>(untyped_value);
  value = item;
}

void assign_function__ActuatorTargetArray__actuators(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<actuator_msgs::msg::ActuatorTarget *>(
    get_function__ActuatorTargetArray__actuators(untyped_member, index));
  const auto & value = *reinterpret_cast<const actuator_msgs::msg::ActuatorTarget *>(untyped_value);
  item = value;
}

void resize_function__ActuatorTargetArray__actuators(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<actuator_msgs::msg::ActuatorTarget> *>(untyped_member);
  member->resize(size);
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember ActuatorTargetArray_message_member_array[2] = {
  {
    "header",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<std_msgs::msg::Header>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(actuator_msgs::msg::ActuatorTargetArray, header),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "actuators",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<actuator_msgs::msg::ActuatorTarget>(),  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(actuator_msgs::msg::ActuatorTargetArray, actuators),  // bytes offset in struct
    nullptr,  // default value
    size_function__ActuatorTargetArray__actuators,  // size() function pointer
    get_const_function__ActuatorTargetArray__actuators,  // get_const(index) function pointer
    get_function__ActuatorTargetArray__actuators,  // get(index) function pointer
    fetch_function__ActuatorTargetArray__actuators,  // fetch(index, &value) function pointer
    assign_function__ActuatorTargetArray__actuators,  // assign(index, value) function pointer
    resize_function__ActuatorTargetArray__actuators  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers ActuatorTargetArray_message_members = {
  "actuator_msgs::msg",  // message namespace
  "ActuatorTargetArray",  // message name
  2,  // number of fields
  sizeof(actuator_msgs::msg::ActuatorTargetArray),
  ActuatorTargetArray_message_member_array,  // message members
  ActuatorTargetArray_init_function,  // function to initialize message memory (memory has to be allocated)
  ActuatorTargetArray_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t ActuatorTargetArray_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &ActuatorTargetArray_message_members,
  get_message_typesupport_handle_function,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace actuator_msgs


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<actuator_msgs::msg::ActuatorTargetArray>()
{
  return &::actuator_msgs::msg::rosidl_typesupport_introspection_cpp::ActuatorTargetArray_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, actuator_msgs, msg, ActuatorTargetArray)() {
  return &::actuator_msgs::msg::rosidl_typesupport_introspection_cpp::ActuatorTargetArray_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
