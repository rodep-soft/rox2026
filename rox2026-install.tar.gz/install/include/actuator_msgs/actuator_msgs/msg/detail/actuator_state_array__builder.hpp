// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from actuator_msgs:msg/ActuatorStateArray.idl
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_STATE_ARRAY__BUILDER_HPP_
#define ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_STATE_ARRAY__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "actuator_msgs/msg/detail/actuator_state_array__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace actuator_msgs
{

namespace msg
{

namespace builder
{

class Init_ActuatorStateArray_actuators
{
public:
  explicit Init_ActuatorStateArray_actuators(::actuator_msgs::msg::ActuatorStateArray & msg)
  : msg_(msg)
  {}
  ::actuator_msgs::msg::ActuatorStateArray actuators(::actuator_msgs::msg::ActuatorStateArray::_actuators_type arg)
  {
    msg_.actuators = std::move(arg);
    return std::move(msg_);
  }

private:
  ::actuator_msgs::msg::ActuatorStateArray msg_;
};

class Init_ActuatorStateArray_header
{
public:
  Init_ActuatorStateArray_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ActuatorStateArray_actuators header(::actuator_msgs::msg::ActuatorStateArray::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ActuatorStateArray_actuators(msg_);
  }

private:
  ::actuator_msgs::msg::ActuatorStateArray msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::actuator_msgs::msg::ActuatorStateArray>()
{
  return actuator_msgs::msg::builder::Init_ActuatorStateArray_header();
}

}  // namespace actuator_msgs

#endif  // ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_STATE_ARRAY__BUILDER_HPP_
