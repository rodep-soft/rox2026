// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from actuator_msgs:msg/ActuatorTarget.idl
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_TARGET__BUILDER_HPP_
#define ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_TARGET__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "actuator_msgs/msg/detail/actuator_target__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace actuator_msgs
{

namespace msg
{

namespace builder
{

class Init_ActuatorTarget_target
{
public:
  explicit Init_ActuatorTarget_target(::actuator_msgs::msg::ActuatorTarget & msg)
  : msg_(msg)
  {}
  ::actuator_msgs::msg::ActuatorTarget target(::actuator_msgs::msg::ActuatorTarget::_target_type arg)
  {
    msg_.target = std::move(arg);
    return std::move(msg_);
  }

private:
  ::actuator_msgs::msg::ActuatorTarget msg_;
};

class Init_ActuatorTarget_logical_id
{
public:
  Init_ActuatorTarget_logical_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ActuatorTarget_target logical_id(::actuator_msgs::msg::ActuatorTarget::_logical_id_type arg)
  {
    msg_.logical_id = std::move(arg);
    return Init_ActuatorTarget_target(msg_);
  }

private:
  ::actuator_msgs::msg::ActuatorTarget msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::actuator_msgs::msg::ActuatorTarget>()
{
  return actuator_msgs::msg::builder::Init_ActuatorTarget_logical_id();
}

}  // namespace actuator_msgs

#endif  // ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_TARGET__BUILDER_HPP_
