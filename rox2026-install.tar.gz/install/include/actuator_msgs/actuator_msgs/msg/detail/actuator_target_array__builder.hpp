// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from actuator_msgs:msg/ActuatorTargetArray.idl
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_TARGET_ARRAY__BUILDER_HPP_
#define ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_TARGET_ARRAY__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "actuator_msgs/msg/detail/actuator_target_array__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace actuator_msgs
{

namespace msg
{

namespace builder
{

class Init_ActuatorTargetArray_actuators
{
public:
  explicit Init_ActuatorTargetArray_actuators(::actuator_msgs::msg::ActuatorTargetArray & msg)
  : msg_(msg)
  {}
  ::actuator_msgs::msg::ActuatorTargetArray actuators(::actuator_msgs::msg::ActuatorTargetArray::_actuators_type arg)
  {
    msg_.actuators = std::move(arg);
    return std::move(msg_);
  }

private:
  ::actuator_msgs::msg::ActuatorTargetArray msg_;
};

class Init_ActuatorTargetArray_header
{
public:
  Init_ActuatorTargetArray_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ActuatorTargetArray_actuators header(::actuator_msgs::msg::ActuatorTargetArray::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ActuatorTargetArray_actuators(msg_);
  }

private:
  ::actuator_msgs::msg::ActuatorTargetArray msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::actuator_msgs::msg::ActuatorTargetArray>()
{
  return actuator_msgs::msg::builder::Init_ActuatorTargetArray_header();
}

}  // namespace actuator_msgs

#endif  // ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_TARGET_ARRAY__BUILDER_HPP_
