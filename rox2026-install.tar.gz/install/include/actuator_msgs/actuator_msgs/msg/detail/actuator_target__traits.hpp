// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from actuator_msgs:msg/ActuatorTarget.idl
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_TARGET__TRAITS_HPP_
#define ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_TARGET__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "actuator_msgs/msg/detail/actuator_target__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace actuator_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ActuatorTarget & msg,
  std::ostream & out)
{
  out << "{";
  // member: logical_id
  {
    out << "logical_id: ";
    rosidl_generator_traits::value_to_yaml(msg.logical_id, out);
    out << ", ";
  }

  // member: target
  {
    out << "target: ";
    rosidl_generator_traits::value_to_yaml(msg.target, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ActuatorTarget & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: logical_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "logical_id: ";
    rosidl_generator_traits::value_to_yaml(msg.logical_id, out);
    out << "\n";
  }

  // member: target
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "target: ";
    rosidl_generator_traits::value_to_yaml(msg.target, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ActuatorTarget & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace actuator_msgs

namespace rosidl_generator_traits
{

[[deprecated("use actuator_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const actuator_msgs::msg::ActuatorTarget & msg,
  std::ostream & out, size_t indentation = 0)
{
  actuator_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use actuator_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const actuator_msgs::msg::ActuatorTarget & msg)
{
  return actuator_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<actuator_msgs::msg::ActuatorTarget>()
{
  return "actuator_msgs::msg::ActuatorTarget";
}

template<>
inline const char * name<actuator_msgs::msg::ActuatorTarget>()
{
  return "actuator_msgs/msg/ActuatorTarget";
}

template<>
struct has_fixed_size<actuator_msgs::msg::ActuatorTarget>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<actuator_msgs::msg::ActuatorTarget>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<actuator_msgs::msg::ActuatorTarget>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_TARGET__TRAITS_HPP_
