// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from actuator_msgs:msg/ActuatorState.idl
// generated code does not contain a copyright notice
#include "actuator_msgs/msg/detail/actuator_state__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
actuator_msgs__msg__ActuatorState__init(actuator_msgs__msg__ActuatorState * msg)
{
  if (!msg) {
    return false;
  }
  // logical_id
  // state
  // position_reference_set
  // position
  // velocity
  // torque_nm
  // current_a
  // temperature
  // fault_code
  return true;
}

void
actuator_msgs__msg__ActuatorState__fini(actuator_msgs__msg__ActuatorState * msg)
{
  if (!msg) {
    return;
  }
  // logical_id
  // state
  // position_reference_set
  // position
  // velocity
  // torque_nm
  // current_a
  // temperature
  // fault_code
}

bool
actuator_msgs__msg__ActuatorState__are_equal(const actuator_msgs__msg__ActuatorState * lhs, const actuator_msgs__msg__ActuatorState * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // logical_id
  if (lhs->logical_id != rhs->logical_id) {
    return false;
  }
  // state
  if (lhs->state != rhs->state) {
    return false;
  }
  // position_reference_set
  if (lhs->position_reference_set != rhs->position_reference_set) {
    return false;
  }
  // position
  if (lhs->position != rhs->position) {
    return false;
  }
  // velocity
  if (lhs->velocity != rhs->velocity) {
    return false;
  }
  // torque_nm
  if (lhs->torque_nm != rhs->torque_nm) {
    return false;
  }
  // current_a
  if (lhs->current_a != rhs->current_a) {
    return false;
  }
  // temperature
  if (lhs->temperature != rhs->temperature) {
    return false;
  }
  // fault_code
  if (lhs->fault_code != rhs->fault_code) {
    return false;
  }
  return true;
}

bool
actuator_msgs__msg__ActuatorState__copy(
  const actuator_msgs__msg__ActuatorState * input,
  actuator_msgs__msg__ActuatorState * output)
{
  if (!input || !output) {
    return false;
  }
  // logical_id
  output->logical_id = input->logical_id;
  // state
  output->state = input->state;
  // position_reference_set
  output->position_reference_set = input->position_reference_set;
  // position
  output->position = input->position;
  // velocity
  output->velocity = input->velocity;
  // torque_nm
  output->torque_nm = input->torque_nm;
  // current_a
  output->current_a = input->current_a;
  // temperature
  output->temperature = input->temperature;
  // fault_code
  output->fault_code = input->fault_code;
  return true;
}

actuator_msgs__msg__ActuatorState *
actuator_msgs__msg__ActuatorState__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  actuator_msgs__msg__ActuatorState * msg = (actuator_msgs__msg__ActuatorState *)allocator.allocate(sizeof(actuator_msgs__msg__ActuatorState), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(actuator_msgs__msg__ActuatorState));
  bool success = actuator_msgs__msg__ActuatorState__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
actuator_msgs__msg__ActuatorState__destroy(actuator_msgs__msg__ActuatorState * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    actuator_msgs__msg__ActuatorState__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
actuator_msgs__msg__ActuatorState__Sequence__init(actuator_msgs__msg__ActuatorState__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  actuator_msgs__msg__ActuatorState * data = NULL;

  if (size) {
    data = (actuator_msgs__msg__ActuatorState *)allocator.zero_allocate(size, sizeof(actuator_msgs__msg__ActuatorState), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = actuator_msgs__msg__ActuatorState__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        actuator_msgs__msg__ActuatorState__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
actuator_msgs__msg__ActuatorState__Sequence__fini(actuator_msgs__msg__ActuatorState__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      actuator_msgs__msg__ActuatorState__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

actuator_msgs__msg__ActuatorState__Sequence *
actuator_msgs__msg__ActuatorState__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  actuator_msgs__msg__ActuatorState__Sequence * array = (actuator_msgs__msg__ActuatorState__Sequence *)allocator.allocate(sizeof(actuator_msgs__msg__ActuatorState__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = actuator_msgs__msg__ActuatorState__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
actuator_msgs__msg__ActuatorState__Sequence__destroy(actuator_msgs__msg__ActuatorState__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    actuator_msgs__msg__ActuatorState__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
actuator_msgs__msg__ActuatorState__Sequence__are_equal(const actuator_msgs__msg__ActuatorState__Sequence * lhs, const actuator_msgs__msg__ActuatorState__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!actuator_msgs__msg__ActuatorState__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
actuator_msgs__msg__ActuatorState__Sequence__copy(
  const actuator_msgs__msg__ActuatorState__Sequence * input,
  actuator_msgs__msg__ActuatorState__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(actuator_msgs__msg__ActuatorState);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    actuator_msgs__msg__ActuatorState * data =
      (actuator_msgs__msg__ActuatorState *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!actuator_msgs__msg__ActuatorState__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          actuator_msgs__msg__ActuatorState__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!actuator_msgs__msg__ActuatorState__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
