// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from actuator_msgs:msg/ActuatorState.idl
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_STATE__STRUCT_HPP_
#define ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_STATE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__actuator_msgs__msg__ActuatorState __attribute__((deprecated))
#else
# define DEPRECATED__actuator_msgs__msg__ActuatorState __declspec(deprecated)
#endif

namespace actuator_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ActuatorState_
{
  using Type = ActuatorState_<ContainerAllocator>;

  explicit ActuatorState_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->logical_id = 0;
      this->state = 0;
      this->position_reference_set = false;
      this->position = 0.0f;
      this->velocity = 0.0f;
      this->torque_nm = 0.0f;
      this->current_a = 0.0f;
      this->temperature = 0.0f;
      this->fault_code = 0ul;
    }
  }

  explicit ActuatorState_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->logical_id = 0;
      this->state = 0;
      this->position_reference_set = false;
      this->position = 0.0f;
      this->velocity = 0.0f;
      this->torque_nm = 0.0f;
      this->current_a = 0.0f;
      this->temperature = 0.0f;
      this->fault_code = 0ul;
    }
  }

  // field types and members
  using _logical_id_type =
    uint16_t;
  _logical_id_type logical_id;
  using _state_type =
    uint8_t;
  _state_type state;
  using _position_reference_set_type =
    bool;
  _position_reference_set_type position_reference_set;
  using _position_type =
    float;
  _position_type position;
  using _velocity_type =
    float;
  _velocity_type velocity;
  using _torque_nm_type =
    float;
  _torque_nm_type torque_nm;
  using _current_a_type =
    float;
  _current_a_type current_a;
  using _temperature_type =
    float;
  _temperature_type temperature;
  using _fault_code_type =
    uint32_t;
  _fault_code_type fault_code;

  // setters for named parameter idiom
  Type & set__logical_id(
    const uint16_t & _arg)
  {
    this->logical_id = _arg;
    return *this;
  }
  Type & set__state(
    const uint8_t & _arg)
  {
    this->state = _arg;
    return *this;
  }
  Type & set__position_reference_set(
    const bool & _arg)
  {
    this->position_reference_set = _arg;
    return *this;
  }
  Type & set__position(
    const float & _arg)
  {
    this->position = _arg;
    return *this;
  }
  Type & set__velocity(
    const float & _arg)
  {
    this->velocity = _arg;
    return *this;
  }
  Type & set__torque_nm(
    const float & _arg)
  {
    this->torque_nm = _arg;
    return *this;
  }
  Type & set__current_a(
    const float & _arg)
  {
    this->current_a = _arg;
    return *this;
  }
  Type & set__temperature(
    const float & _arg)
  {
    this->temperature = _arg;
    return *this;
  }
  Type & set__fault_code(
    const uint32_t & _arg)
  {
    this->fault_code = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t STATE_OFFLINE =
    0u;
  static constexpr uint8_t STATE_INITIALIZING =
    1u;
  static constexpr uint8_t STATE_READY =
    2u;
  static constexpr uint8_t STATE_ERROR =
    3u;

  // pointer types
  using RawPtr =
    actuator_msgs::msg::ActuatorState_<ContainerAllocator> *;
  using ConstRawPtr =
    const actuator_msgs::msg::ActuatorState_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<actuator_msgs::msg::ActuatorState_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<actuator_msgs::msg::ActuatorState_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      actuator_msgs::msg::ActuatorState_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<actuator_msgs::msg::ActuatorState_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      actuator_msgs::msg::ActuatorState_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<actuator_msgs::msg::ActuatorState_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<actuator_msgs::msg::ActuatorState_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<actuator_msgs::msg::ActuatorState_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__actuator_msgs__msg__ActuatorState
    std::shared_ptr<actuator_msgs::msg::ActuatorState_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__actuator_msgs__msg__ActuatorState
    std::shared_ptr<actuator_msgs::msg::ActuatorState_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ActuatorState_ & other) const
  {
    if (this->logical_id != other.logical_id) {
      return false;
    }
    if (this->state != other.state) {
      return false;
    }
    if (this->position_reference_set != other.position_reference_set) {
      return false;
    }
    if (this->position != other.position) {
      return false;
    }
    if (this->velocity != other.velocity) {
      return false;
    }
    if (this->torque_nm != other.torque_nm) {
      return false;
    }
    if (this->current_a != other.current_a) {
      return false;
    }
    if (this->temperature != other.temperature) {
      return false;
    }
    if (this->fault_code != other.fault_code) {
      return false;
    }
    return true;
  }
  bool operator!=(const ActuatorState_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ActuatorState_

// alias to use template instance with default allocator
using ActuatorState =
  actuator_msgs::msg::ActuatorState_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ActuatorState_<ContainerAllocator>::STATE_OFFLINE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ActuatorState_<ContainerAllocator>::STATE_INITIALIZING;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ActuatorState_<ContainerAllocator>::STATE_READY;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ActuatorState_<ContainerAllocator>::STATE_ERROR;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace actuator_msgs

#endif  // ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_STATE__STRUCT_HPP_
