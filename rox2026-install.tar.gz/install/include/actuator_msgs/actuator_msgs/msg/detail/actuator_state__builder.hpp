// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from actuator_msgs:msg/ActuatorState.idl
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_STATE__BUILDER_HPP_
#define ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "actuator_msgs/msg/detail/actuator_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace actuator_msgs
{

namespace msg
{

namespace builder
{

class Init_ActuatorState_fault_code
{
public:
  explicit Init_ActuatorState_fault_code(::actuator_msgs::msg::ActuatorState & msg)
  : msg_(msg)
  {}
  ::actuator_msgs::msg::ActuatorState fault_code(::actuator_msgs::msg::ActuatorState::_fault_code_type arg)
  {
    msg_.fault_code = std::move(arg);
    return std::move(msg_);
  }

private:
  ::actuator_msgs::msg::ActuatorState msg_;
};

class Init_ActuatorState_temperature
{
public:
  explicit Init_ActuatorState_temperature(::actuator_msgs::msg::ActuatorState & msg)
  : msg_(msg)
  {}
  Init_ActuatorState_fault_code temperature(::actuator_msgs::msg::ActuatorState::_temperature_type arg)
  {
    msg_.temperature = std::move(arg);
    return Init_ActuatorState_fault_code(msg_);
  }

private:
  ::actuator_msgs::msg::ActuatorState msg_;
};

class Init_ActuatorState_current_a
{
public:
  explicit Init_ActuatorState_current_a(::actuator_msgs::msg::ActuatorState & msg)
  : msg_(msg)
  {}
  Init_ActuatorState_temperature current_a(::actuator_msgs::msg::ActuatorState::_current_a_type arg)
  {
    msg_.current_a = std::move(arg);
    return Init_ActuatorState_temperature(msg_);
  }

private:
  ::actuator_msgs::msg::ActuatorState msg_;
};

class Init_ActuatorState_torque_nm
{
public:
  explicit Init_ActuatorState_torque_nm(::actuator_msgs::msg::ActuatorState & msg)
  : msg_(msg)
  {}
  Init_ActuatorState_current_a torque_nm(::actuator_msgs::msg::ActuatorState::_torque_nm_type arg)
  {
    msg_.torque_nm = std::move(arg);
    return Init_ActuatorState_current_a(msg_);
  }

private:
  ::actuator_msgs::msg::ActuatorState msg_;
};

class Init_ActuatorState_velocity
{
public:
  explicit Init_ActuatorState_velocity(::actuator_msgs::msg::ActuatorState & msg)
  : msg_(msg)
  {}
  Init_ActuatorState_torque_nm velocity(::actuator_msgs::msg::ActuatorState::_velocity_type arg)
  {
    msg_.velocity = std::move(arg);
    return Init_ActuatorState_torque_nm(msg_);
  }

private:
  ::actuator_msgs::msg::ActuatorState msg_;
};

class Init_ActuatorState_position
{
public:
  explicit Init_ActuatorState_position(::actuator_msgs::msg::ActuatorState & msg)
  : msg_(msg)
  {}
  Init_ActuatorState_velocity position(::actuator_msgs::msg::ActuatorState::_position_type arg)
  {
    msg_.position = std::move(arg);
    return Init_ActuatorState_velocity(msg_);
  }

private:
  ::actuator_msgs::msg::ActuatorState msg_;
};

class Init_ActuatorState_position_reference_set
{
public:
  explicit Init_ActuatorState_position_reference_set(::actuator_msgs::msg::ActuatorState & msg)
  : msg_(msg)
  {}
  Init_ActuatorState_position position_reference_set(::actuator_msgs::msg::ActuatorState::_position_reference_set_type arg)
  {
    msg_.position_reference_set = std::move(arg);
    return Init_ActuatorState_position(msg_);
  }

private:
  ::actuator_msgs::msg::ActuatorState msg_;
};

class Init_ActuatorState_state
{
public:
  explicit Init_ActuatorState_state(::actuator_msgs::msg::ActuatorState & msg)
  : msg_(msg)
  {}
  Init_ActuatorState_position_reference_set state(::actuator_msgs::msg::ActuatorState::_state_type arg)
  {
    msg_.state = std::move(arg);
    return Init_ActuatorState_position_reference_set(msg_);
  }

private:
  ::actuator_msgs::msg::ActuatorState msg_;
};

class Init_ActuatorState_logical_id
{
public:
  Init_ActuatorState_logical_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ActuatorState_state logical_id(::actuator_msgs::msg::ActuatorState::_logical_id_type arg)
  {
    msg_.logical_id = std::move(arg);
    return Init_ActuatorState_state(msg_);
  }

private:
  ::actuator_msgs::msg::ActuatorState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::actuator_msgs::msg::ActuatorState>()
{
  return actuator_msgs::msg::builder::Init_ActuatorState_logical_id();
}

}  // namespace actuator_msgs

#endif  // ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_STATE__BUILDER_HPP_
