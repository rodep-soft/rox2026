// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from actuator_msgs:msg/ActuatorTargetArray.idl
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_TARGET_ARRAY__TRAITS_HPP_
#define ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_TARGET_ARRAY__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "actuator_msgs/msg/detail/actuator_target_array__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'actuators'
#include "actuator_msgs/msg/detail/actuator_target__traits.hpp"

namespace actuator_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ActuatorTargetArray & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: actuators
  {
    if (msg.actuators.size() == 0) {
      out << "actuators: []";
    } else {
      out << "actuators: [";
      size_t pending_items = msg.actuators.size();
      for (auto item : msg.actuators) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ActuatorTargetArray & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: actuators
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.actuators.size() == 0) {
      out << "actuators: []\n";
    } else {
      out << "actuators:\n";
      for (auto item : msg.actuators) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ActuatorTargetArray & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace actuator_msgs

namespace rosidl_generator_traits
{

[[deprecated("use actuator_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const actuator_msgs::msg::ActuatorTargetArray & msg,
  std::ostream & out, size_t indentation = 0)
{
  actuator_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use actuator_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const actuator_msgs::msg::ActuatorTargetArray & msg)
{
  return actuator_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<actuator_msgs::msg::ActuatorTargetArray>()
{
  return "actuator_msgs::msg::ActuatorTargetArray";
}

template<>
inline const char * name<actuator_msgs::msg::ActuatorTargetArray>()
{
  return "actuator_msgs/msg/ActuatorTargetArray";
}

template<>
struct has_fixed_size<actuator_msgs::msg::ActuatorTargetArray>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<actuator_msgs::msg::ActuatorTargetArray>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<actuator_msgs::msg::ActuatorTargetArray>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_TARGET_ARRAY__TRAITS_HPP_
