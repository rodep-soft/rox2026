// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from actuator_msgs:msg/ActuatorState.idl
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_STATE__STRUCT_H_
#define ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'STATE_OFFLINE'.
enum
{
  actuator_msgs__msg__ActuatorState__STATE_OFFLINE = 0
};

/// Constant 'STATE_INITIALIZING'.
enum
{
  actuator_msgs__msg__ActuatorState__STATE_INITIALIZING = 1
};

/// Constant 'STATE_READY'.
enum
{
  actuator_msgs__msg__ActuatorState__STATE_READY = 2
};

/// Constant 'STATE_ERROR'.
enum
{
  actuator_msgs__msg__ActuatorState__STATE_ERROR = 3
};

/// Struct defined in msg/ActuatorState in the package actuator_msgs.
/**
  * ActuatorState.msg
 */
typedef struct actuator_msgs__msg__ActuatorState
{
  uint16_t logical_id;
  uint8_t state;
  bool position_reference_set;
  float position;
  float velocity;
  float torque_nm;
  float current_a;
  float temperature;
  uint32_t fault_code;
} actuator_msgs__msg__ActuatorState;

// Struct for a sequence of actuator_msgs__msg__ActuatorState.
typedef struct actuator_msgs__msg__ActuatorState__Sequence
{
  actuator_msgs__msg__ActuatorState * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} actuator_msgs__msg__ActuatorState__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_STATE__STRUCT_H_
