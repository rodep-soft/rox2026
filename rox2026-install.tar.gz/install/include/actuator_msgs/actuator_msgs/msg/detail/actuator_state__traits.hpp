// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from actuator_msgs:msg/ActuatorState.idl
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_STATE__TRAITS_HPP_
#define ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_STATE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "actuator_msgs/msg/detail/actuator_state__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace actuator_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ActuatorState & msg,
  std::ostream & out)
{
  out << "{";
  // member: logical_id
  {
    out << "logical_id: ";
    rosidl_generator_traits::value_to_yaml(msg.logical_id, out);
    out << ", ";
  }

  // member: state
  {
    out << "state: ";
    rosidl_generator_traits::value_to_yaml(msg.state, out);
    out << ", ";
  }

  // member: position_reference_set
  {
    out << "position_reference_set: ";
    rosidl_generator_traits::value_to_yaml(msg.position_reference_set, out);
    out << ", ";
  }

  // member: position
  {
    out << "position: ";
    rosidl_generator_traits::value_to_yaml(msg.position, out);
    out << ", ";
  }

  // member: velocity
  {
    out << "velocity: ";
    rosidl_generator_traits::value_to_yaml(msg.velocity, out);
    out << ", ";
  }

  // member: torque_nm
  {
    out << "torque_nm: ";
    rosidl_generator_traits::value_to_yaml(msg.torque_nm, out);
    out << ", ";
  }

  // member: current_a
  {
    out << "current_a: ";
    rosidl_generator_traits::value_to_yaml(msg.current_a, out);
    out << ", ";
  }

  // member: temperature
  {
    out << "temperature: ";
    rosidl_generator_traits::value_to_yaml(msg.temperature, out);
    out << ", ";
  }

  // member: fault_code
  {
    out << "fault_code: ";
    rosidl_generator_traits::value_to_yaml(msg.fault_code, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ActuatorState & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: logical_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "logical_id: ";
    rosidl_generator_traits::value_to_yaml(msg.logical_id, out);
    out << "\n";
  }

  // member: state
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "state: ";
    rosidl_generator_traits::value_to_yaml(msg.state, out);
    out << "\n";
  }

  // member: position_reference_set
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "position_reference_set: ";
    rosidl_generator_traits::value_to_yaml(msg.position_reference_set, out);
    out << "\n";
  }

  // member: position
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "position: ";
    rosidl_generator_traits::value_to_yaml(msg.position, out);
    out << "\n";
  }

  // member: velocity
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "velocity: ";
    rosidl_generator_traits::value_to_yaml(msg.velocity, out);
    out << "\n";
  }

  // member: torque_nm
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "torque_nm: ";
    rosidl_generator_traits::value_to_yaml(msg.torque_nm, out);
    out << "\n";
  }

  // member: current_a
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "current_a: ";
    rosidl_generator_traits::value_to_yaml(msg.current_a, out);
    out << "\n";
  }

  // member: temperature
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "temperature: ";
    rosidl_generator_traits::value_to_yaml(msg.temperature, out);
    out << "\n";
  }

  // member: fault_code
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fault_code: ";
    rosidl_generator_traits::value_to_yaml(msg.fault_code, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ActuatorState & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace actuator_msgs

namespace rosidl_generator_traits
{

[[deprecated("use actuator_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const actuator_msgs::msg::ActuatorState & msg,
  std::ostream & out, size_t indentation = 0)
{
  actuator_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use actuator_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const actuator_msgs::msg::ActuatorState & msg)
{
  return actuator_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<actuator_msgs::msg::ActuatorState>()
{
  return "actuator_msgs::msg::ActuatorState";
}

template<>
inline const char * name<actuator_msgs::msg::ActuatorState>()
{
  return "actuator_msgs/msg/ActuatorState";
}

template<>
struct has_fixed_size<actuator_msgs::msg::ActuatorState>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<actuator_msgs::msg::ActuatorState>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<actuator_msgs::msg::ActuatorState>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_STATE__TRAITS_HPP_
