// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from actuator_msgs:msg/ActuatorTarget.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "actuator_msgs/msg/detail/actuator_target__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace actuator_msgs
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void ActuatorTarget_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) actuator_msgs::msg::ActuatorTarget(_init);
}

void ActuatorTarget_fini_function(void * message_memory)
{
  auto typed_message = static_cast<actuator_msgs::msg::ActuatorTarget *>(message_memory);
  typed_message->~ActuatorTarget();
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember ActuatorTarget_message_member_array[2] = {
  {
    "logical_id",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(actuator_msgs::msg::ActuatorTarget, logical_id),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "target",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(actuator_msgs::msg::ActuatorTarget, target),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers ActuatorTarget_message_members = {
  "actuator_msgs::msg",  // message namespace
  "ActuatorTarget",  // message name
  2,  // number of fields
  sizeof(actuator_msgs::msg::ActuatorTarget),
  ActuatorTarget_message_member_array,  // message members
  ActuatorTarget_init_function,  // function to initialize message memory (memory has to be allocated)
  ActuatorTarget_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t ActuatorTarget_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &ActuatorTarget_message_members,
  get_message_typesupport_handle_function,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace actuator_msgs


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<actuator_msgs::msg::ActuatorTarget>()
{
  return &::actuator_msgs::msg::rosidl_typesupport_introspection_cpp::ActuatorTarget_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, actuator_msgs, msg, ActuatorTarget)() {
  return &::actuator_msgs::msg::rosidl_typesupport_introspection_cpp::ActuatorTarget_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
