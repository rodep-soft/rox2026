// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from actuator_msgs:msg/ActuatorTarget.idl
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_TARGET__STRUCT_HPP_
#define ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_TARGET__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__actuator_msgs__msg__ActuatorTarget __attribute__((deprecated))
#else
# define DEPRECATED__actuator_msgs__msg__ActuatorTarget __declspec(deprecated)
#endif

namespace actuator_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ActuatorTarget_
{
  using Type = ActuatorTarget_<ContainerAllocator>;

  explicit ActuatorTarget_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->logical_id = 0;
      this->target = 0.0f;
    }
  }

  explicit ActuatorTarget_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->logical_id = 0;
      this->target = 0.0f;
    }
  }

  // field types and members
  using _logical_id_type =
    uint16_t;
  _logical_id_type logical_id;
  using _target_type =
    float;
  _target_type target;

  // setters for named parameter idiom
  Type & set__logical_id(
    const uint16_t & _arg)
  {
    this->logical_id = _arg;
    return *this;
  }
  Type & set__target(
    const float & _arg)
  {
    this->target = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    actuator_msgs::msg::ActuatorTarget_<ContainerAllocator> *;
  using ConstRawPtr =
    const actuator_msgs::msg::ActuatorTarget_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<actuator_msgs::msg::ActuatorTarget_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<actuator_msgs::msg::ActuatorTarget_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      actuator_msgs::msg::ActuatorTarget_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<actuator_msgs::msg::ActuatorTarget_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      actuator_msgs::msg::ActuatorTarget_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<actuator_msgs::msg::ActuatorTarget_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<actuator_msgs::msg::ActuatorTarget_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<actuator_msgs::msg::ActuatorTarget_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__actuator_msgs__msg__ActuatorTarget
    std::shared_ptr<actuator_msgs::msg::ActuatorTarget_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__actuator_msgs__msg__ActuatorTarget
    std::shared_ptr<actuator_msgs::msg::ActuatorTarget_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ActuatorTarget_ & other) const
  {
    if (this->logical_id != other.logical_id) {
      return false;
    }
    if (this->target != other.target) {
      return false;
    }
    return true;
  }
  bool operator!=(const ActuatorTarget_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ActuatorTarget_

// alias to use template instance with default allocator
using ActuatorTarget =
  actuator_msgs::msg::ActuatorTarget_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace actuator_msgs

#endif  // ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_TARGET__STRUCT_HPP_
