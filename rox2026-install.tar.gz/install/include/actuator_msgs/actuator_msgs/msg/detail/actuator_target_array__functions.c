// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from actuator_msgs:msg/ActuatorTargetArray.idl
// generated code does not contain a copyright notice
#include "actuator_msgs/msg/detail/actuator_target_array__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `actuators`
#include "actuator_msgs/msg/detail/actuator_target__functions.h"

bool
actuator_msgs__msg__ActuatorTargetArray__init(actuator_msgs__msg__ActuatorTargetArray * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    actuator_msgs__msg__ActuatorTargetArray__fini(msg);
    return false;
  }
  // actuators
  if (!actuator_msgs__msg__ActuatorTarget__Sequence__init(&msg->actuators, 0)) {
    actuator_msgs__msg__ActuatorTargetArray__fini(msg);
    return false;
  }
  return true;
}

void
actuator_msgs__msg__ActuatorTargetArray__fini(actuator_msgs__msg__ActuatorTargetArray * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // actuators
  actuator_msgs__msg__ActuatorTarget__Sequence__fini(&msg->actuators);
}

bool
actuator_msgs__msg__ActuatorTargetArray__are_equal(const actuator_msgs__msg__ActuatorTargetArray * lhs, const actuator_msgs__msg__ActuatorTargetArray * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // actuators
  if (!actuator_msgs__msg__ActuatorTarget__Sequence__are_equal(
      &(lhs->actuators), &(rhs->actuators)))
  {
    return false;
  }
  return true;
}

bool
actuator_msgs__msg__ActuatorTargetArray__copy(
  const actuator_msgs__msg__ActuatorTargetArray * input,
  actuator_msgs__msg__ActuatorTargetArray * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // actuators
  if (!actuator_msgs__msg__ActuatorTarget__Sequence__copy(
      &(input->actuators), &(output->actuators)))
  {
    return false;
  }
  return true;
}

actuator_msgs__msg__ActuatorTargetArray *
actuator_msgs__msg__ActuatorTargetArray__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  actuator_msgs__msg__ActuatorTargetArray * msg = (actuator_msgs__msg__ActuatorTargetArray *)allocator.allocate(sizeof(actuator_msgs__msg__ActuatorTargetArray), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(actuator_msgs__msg__ActuatorTargetArray));
  bool success = actuator_msgs__msg__ActuatorTargetArray__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
actuator_msgs__msg__ActuatorTargetArray__destroy(actuator_msgs__msg__ActuatorTargetArray * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    actuator_msgs__msg__ActuatorTargetArray__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
actuator_msgs__msg__ActuatorTargetArray__Sequence__init(actuator_msgs__msg__ActuatorTargetArray__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  actuator_msgs__msg__ActuatorTargetArray * data = NULL;

  if (size) {
    data = (actuator_msgs__msg__ActuatorTargetArray *)allocator.zero_allocate(size, sizeof(actuator_msgs__msg__ActuatorTargetArray), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = actuator_msgs__msg__ActuatorTargetArray__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        actuator_msgs__msg__ActuatorTargetArray__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
actuator_msgs__msg__ActuatorTargetArray__Sequence__fini(actuator_msgs__msg__ActuatorTargetArray__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      actuator_msgs__msg__ActuatorTargetArray__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

actuator_msgs__msg__ActuatorTargetArray__Sequence *
actuator_msgs__msg__ActuatorTargetArray__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  actuator_msgs__msg__ActuatorTargetArray__Sequence * array = (actuator_msgs__msg__ActuatorTargetArray__Sequence *)allocator.allocate(sizeof(actuator_msgs__msg__ActuatorTargetArray__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = actuator_msgs__msg__ActuatorTargetArray__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
actuator_msgs__msg__ActuatorTargetArray__Sequence__destroy(actuator_msgs__msg__ActuatorTargetArray__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    actuator_msgs__msg__ActuatorTargetArray__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
actuator_msgs__msg__ActuatorTargetArray__Sequence__are_equal(const actuator_msgs__msg__ActuatorTargetArray__Sequence * lhs, const actuator_msgs__msg__ActuatorTargetArray__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!actuator_msgs__msg__ActuatorTargetArray__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
actuator_msgs__msg__ActuatorTargetArray__Sequence__copy(
  const actuator_msgs__msg__ActuatorTargetArray__Sequence * input,
  actuator_msgs__msg__ActuatorTargetArray__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(actuator_msgs__msg__ActuatorTargetArray);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    actuator_msgs__msg__ActuatorTargetArray * data =
      (actuator_msgs__msg__ActuatorTargetArray *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!actuator_msgs__msg__ActuatorTargetArray__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          actuator_msgs__msg__ActuatorTargetArray__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!actuator_msgs__msg__ActuatorTargetArray__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
