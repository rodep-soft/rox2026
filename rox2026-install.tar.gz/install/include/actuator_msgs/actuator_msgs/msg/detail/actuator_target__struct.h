// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from actuator_msgs:msg/ActuatorTarget.idl
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_TARGET__STRUCT_H_
#define ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_TARGET__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/ActuatorTarget in the package actuator_msgs.
typedef struct actuator_msgs__msg__ActuatorTarget
{
  uint16_t logical_id;
  float target;
} actuator_msgs__msg__ActuatorTarget;

// Struct for a sequence of actuator_msgs__msg__ActuatorTarget.
typedef struct actuator_msgs__msg__ActuatorTarget__Sequence
{
  actuator_msgs__msg__ActuatorTarget * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} actuator_msgs__msg__ActuatorTarget__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ACTUATOR_MSGS__MSG__DETAIL__ACTUATOR_TARGET__STRUCT_H_
