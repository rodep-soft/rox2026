// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from actuator_msgs:msg/ActuatorStateArray.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "actuator_msgs/msg/detail/actuator_state_array__rosidl_typesupport_introspection_c.h"
#include "actuator_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "actuator_msgs/msg/detail/actuator_state_array__functions.h"
#include "actuator_msgs/msg/detail/actuator_state_array__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"
// Member `actuators`
#include "actuator_msgs/msg/actuator_state.h"
// Member `actuators`
#include "actuator_msgs/msg/detail/actuator_state__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__ActuatorStateArray_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  actuator_msgs__msg__ActuatorStateArray__init(message_memory);
}

void actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__ActuatorStateArray_fini_function(void * message_memory)
{
  actuator_msgs__msg__ActuatorStateArray__fini(message_memory);
}

size_t actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__size_function__ActuatorStateArray__actuators(
  const void * untyped_member)
{
  const actuator_msgs__msg__ActuatorState__Sequence * member =
    (const actuator_msgs__msg__ActuatorState__Sequence *)(untyped_member);
  return member->size;
}

const void * actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__get_const_function__ActuatorStateArray__actuators(
  const void * untyped_member, size_t index)
{
  const actuator_msgs__msg__ActuatorState__Sequence * member =
    (const actuator_msgs__msg__ActuatorState__Sequence *)(untyped_member);
  return &member->data[index];
}

void * actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__get_function__ActuatorStateArray__actuators(
  void * untyped_member, size_t index)
{
  actuator_msgs__msg__ActuatorState__Sequence * member =
    (actuator_msgs__msg__ActuatorState__Sequence *)(untyped_member);
  return &member->data[index];
}

void actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__fetch_function__ActuatorStateArray__actuators(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const actuator_msgs__msg__ActuatorState * item =
    ((const actuator_msgs__msg__ActuatorState *)
    actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__get_const_function__ActuatorStateArray__actuators(untyped_member, index));
  actuator_msgs__msg__ActuatorState * value =
    (actuator_msgs__msg__ActuatorState *)(untyped_value);
  *value = *item;
}

void actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__assign_function__ActuatorStateArray__actuators(
  void * untyped_member, size_t index, const void * untyped_value)
{
  actuator_msgs__msg__ActuatorState * item =
    ((actuator_msgs__msg__ActuatorState *)
    actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__get_function__ActuatorStateArray__actuators(untyped_member, index));
  const actuator_msgs__msg__ActuatorState * value =
    (const actuator_msgs__msg__ActuatorState *)(untyped_value);
  *item = *value;
}

bool actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__resize_function__ActuatorStateArray__actuators(
  void * untyped_member, size_t size)
{
  actuator_msgs__msg__ActuatorState__Sequence * member =
    (actuator_msgs__msg__ActuatorState__Sequence *)(untyped_member);
  actuator_msgs__msg__ActuatorState__Sequence__fini(member);
  return actuator_msgs__msg__ActuatorState__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__ActuatorStateArray_message_member_array[2] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(actuator_msgs__msg__ActuatorStateArray, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "actuators",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(actuator_msgs__msg__ActuatorStateArray, actuators),  // bytes offset in struct
    NULL,  // default value
    actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__size_function__ActuatorStateArray__actuators,  // size() function pointer
    actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__get_const_function__ActuatorStateArray__actuators,  // get_const(index) function pointer
    actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__get_function__ActuatorStateArray__actuators,  // get(index) function pointer
    actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__fetch_function__ActuatorStateArray__actuators,  // fetch(index, &value) function pointer
    actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__assign_function__ActuatorStateArray__actuators,  // assign(index, value) function pointer
    actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__resize_function__ActuatorStateArray__actuators  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__ActuatorStateArray_message_members = {
  "actuator_msgs__msg",  // message namespace
  "ActuatorStateArray",  // message name
  2,  // number of fields
  sizeof(actuator_msgs__msg__ActuatorStateArray),
  actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__ActuatorStateArray_message_member_array,  // message members
  actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__ActuatorStateArray_init_function,  // function to initialize message memory (memory has to be allocated)
  actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__ActuatorStateArray_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__ActuatorStateArray_message_type_support_handle = {
  0,
  &actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__ActuatorStateArray_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_actuator_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, actuator_msgs, msg, ActuatorStateArray)() {
  actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__ActuatorStateArray_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__ActuatorStateArray_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, actuator_msgs, msg, ActuatorState)();
  if (!actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__ActuatorStateArray_message_type_support_handle.typesupport_identifier) {
    actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__ActuatorStateArray_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &actuator_msgs__msg__ActuatorStateArray__rosidl_typesupport_introspection_c__ActuatorStateArray_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
