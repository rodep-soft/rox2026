// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__MSG__ACTUATOR_TARGET_HPP_
#define ACTUATOR_MSGS__MSG__ACTUATOR_TARGET_HPP_

#include "actuator_msgs/msg/detail/actuator_target__struct.hpp"
#include "actuator_msgs/msg/detail/actuator_target__builder.hpp"
#include "actuator_msgs/msg/detail/actuator_target__traits.hpp"
#include "actuator_msgs/msg/detail/actuator_target__type_support.hpp"

#endif  // ACTUATOR_MSGS__MSG__ACTUATOR_TARGET_HPP_
