// generated from rosidl_generator_c/resource/idl.h.em
// with input from actuator_msgs:srv/SetPosition.idl
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__SRV__SET_POSITION_H_
#define ACTUATOR_MSGS__SRV__SET_POSITION_H_

#include "actuator_msgs/srv/detail/set_position__struct.h"
#include "actuator_msgs/srv/detail/set_position__functions.h"
#include "actuator_msgs/srv/detail/set_position__type_support.h"

#endif  // ACTUATOR_MSGS__SRV__SET_POSITION_H_
