// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from actuator_msgs:srv/SetPosition.idl
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__SRV__DETAIL__SET_POSITION__BUILDER_HPP_
#define ACTUATOR_MSGS__SRV__DETAIL__SET_POSITION__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "actuator_msgs/srv/detail/set_position__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace actuator_msgs
{

namespace srv
{

namespace builder
{

class Init_SetPosition_Request_position
{
public:
  explicit Init_SetPosition_Request_position(::actuator_msgs::srv::SetPosition_Request & msg)
  : msg_(msg)
  {}
  ::actuator_msgs::srv::SetPosition_Request position(::actuator_msgs::srv::SetPosition_Request::_position_type arg)
  {
    msg_.position = std::move(arg);
    return std::move(msg_);
  }

private:
  ::actuator_msgs::srv::SetPosition_Request msg_;
};

class Init_SetPosition_Request_logical_id
{
public:
  Init_SetPosition_Request_logical_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SetPosition_Request_position logical_id(::actuator_msgs::srv::SetPosition_Request::_logical_id_type arg)
  {
    msg_.logical_id = std::move(arg);
    return Init_SetPosition_Request_position(msg_);
  }

private:
  ::actuator_msgs::srv::SetPosition_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::actuator_msgs::srv::SetPosition_Request>()
{
  return actuator_msgs::srv::builder::Init_SetPosition_Request_logical_id();
}

}  // namespace actuator_msgs


namespace actuator_msgs
{

namespace srv
{

namespace builder
{

class Init_SetPosition_Response_message
{
public:
  explicit Init_SetPosition_Response_message(::actuator_msgs::srv::SetPosition_Response & msg)
  : msg_(msg)
  {}
  ::actuator_msgs::srv::SetPosition_Response message(::actuator_msgs::srv::SetPosition_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::actuator_msgs::srv::SetPosition_Response msg_;
};

class Init_SetPosition_Response_success
{
public:
  Init_SetPosition_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SetPosition_Response_message success(::actuator_msgs::srv::SetPosition_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_SetPosition_Response_message(msg_);
  }

private:
  ::actuator_msgs::srv::SetPosition_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::actuator_msgs::srv::SetPosition_Response>()
{
  return actuator_msgs::srv::builder::Init_SetPosition_Response_success();
}

}  // namespace actuator_msgs

#endif  // ACTUATOR_MSGS__SRV__DETAIL__SET_POSITION__BUILDER_HPP_
