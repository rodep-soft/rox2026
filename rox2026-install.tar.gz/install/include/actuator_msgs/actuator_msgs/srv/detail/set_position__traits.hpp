// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from actuator_msgs:srv/SetPosition.idl
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__SRV__DETAIL__SET_POSITION__TRAITS_HPP_
#define ACTUATOR_MSGS__SRV__DETAIL__SET_POSITION__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "actuator_msgs/srv/detail/set_position__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace actuator_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const SetPosition_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: logical_id
  {
    out << "logical_id: ";
    rosidl_generator_traits::value_to_yaml(msg.logical_id, out);
    out << ", ";
  }

  // member: position
  {
    out << "position: ";
    rosidl_generator_traits::value_to_yaml(msg.position, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SetPosition_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: logical_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "logical_id: ";
    rosidl_generator_traits::value_to_yaml(msg.logical_id, out);
    out << "\n";
  }

  // member: position
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "position: ";
    rosidl_generator_traits::value_to_yaml(msg.position, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SetPosition_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace actuator_msgs

namespace rosidl_generator_traits
{

[[deprecated("use actuator_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const actuator_msgs::srv::SetPosition_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  actuator_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use actuator_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const actuator_msgs::srv::SetPosition_Request & msg)
{
  return actuator_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<actuator_msgs::srv::SetPosition_Request>()
{
  return "actuator_msgs::srv::SetPosition_Request";
}

template<>
inline const char * name<actuator_msgs::srv::SetPosition_Request>()
{
  return "actuator_msgs/srv/SetPosition_Request";
}

template<>
struct has_fixed_size<actuator_msgs::srv::SetPosition_Request>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<actuator_msgs::srv::SetPosition_Request>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<actuator_msgs::srv::SetPosition_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace actuator_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const SetPosition_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: success
  {
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << ", ";
  }

  // member: message
  {
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SetPosition_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: success
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << "\n";
  }

  // member: message
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SetPosition_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace actuator_msgs

namespace rosidl_generator_traits
{

[[deprecated("use actuator_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const actuator_msgs::srv::SetPosition_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  actuator_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use actuator_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const actuator_msgs::srv::SetPosition_Response & msg)
{
  return actuator_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<actuator_msgs::srv::SetPosition_Response>()
{
  return "actuator_msgs::srv::SetPosition_Response";
}

template<>
inline const char * name<actuator_msgs::srv::SetPosition_Response>()
{
  return "actuator_msgs/srv/SetPosition_Response";
}

template<>
struct has_fixed_size<actuator_msgs::srv::SetPosition_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<actuator_msgs::srv::SetPosition_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<actuator_msgs::srv::SetPosition_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<actuator_msgs::srv::SetPosition>()
{
  return "actuator_msgs::srv::SetPosition";
}

template<>
inline const char * name<actuator_msgs::srv::SetPosition>()
{
  return "actuator_msgs/srv/SetPosition";
}

template<>
struct has_fixed_size<actuator_msgs::srv::SetPosition>
  : std::integral_constant<
    bool,
    has_fixed_size<actuator_msgs::srv::SetPosition_Request>::value &&
    has_fixed_size<actuator_msgs::srv::SetPosition_Response>::value
  >
{
};

template<>
struct has_bounded_size<actuator_msgs::srv::SetPosition>
  : std::integral_constant<
    bool,
    has_bounded_size<actuator_msgs::srv::SetPosition_Request>::value &&
    has_bounded_size<actuator_msgs::srv::SetPosition_Response>::value
  >
{
};

template<>
struct is_service<actuator_msgs::srv::SetPosition>
  : std::true_type
{
};

template<>
struct is_service_request<actuator_msgs::srv::SetPosition_Request>
  : std::true_type
{
};

template<>
struct is_service_response<actuator_msgs::srv::SetPosition_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // ACTUATOR_MSGS__SRV__DETAIL__SET_POSITION__TRAITS_HPP_
