// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from actuator_msgs:srv/SetPosition.idl
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__SRV__DETAIL__SET_POSITION__STRUCT_HPP_
#define ACTUATOR_MSGS__SRV__DETAIL__SET_POSITION__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__actuator_msgs__srv__SetPosition_Request __attribute__((deprecated))
#else
# define DEPRECATED__actuator_msgs__srv__SetPosition_Request __declspec(deprecated)
#endif

namespace actuator_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct SetPosition_Request_
{
  using Type = SetPosition_Request_<ContainerAllocator>;

  explicit SetPosition_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->logical_id = 0;
      this->position = 0.0f;
    }
  }

  explicit SetPosition_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->logical_id = 0;
      this->position = 0.0f;
    }
  }

  // field types and members
  using _logical_id_type =
    uint16_t;
  _logical_id_type logical_id;
  using _position_type =
    float;
  _position_type position;

  // setters for named parameter idiom
  Type & set__logical_id(
    const uint16_t & _arg)
  {
    this->logical_id = _arg;
    return *this;
  }
  Type & set__position(
    const float & _arg)
  {
    this->position = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    actuator_msgs::srv::SetPosition_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const actuator_msgs::srv::SetPosition_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<actuator_msgs::srv::SetPosition_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<actuator_msgs::srv::SetPosition_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      actuator_msgs::srv::SetPosition_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<actuator_msgs::srv::SetPosition_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      actuator_msgs::srv::SetPosition_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<actuator_msgs::srv::SetPosition_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<actuator_msgs::srv::SetPosition_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<actuator_msgs::srv::SetPosition_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__actuator_msgs__srv__SetPosition_Request
    std::shared_ptr<actuator_msgs::srv::SetPosition_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__actuator_msgs__srv__SetPosition_Request
    std::shared_ptr<actuator_msgs::srv::SetPosition_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SetPosition_Request_ & other) const
  {
    if (this->logical_id != other.logical_id) {
      return false;
    }
    if (this->position != other.position) {
      return false;
    }
    return true;
  }
  bool operator!=(const SetPosition_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SetPosition_Request_

// alias to use template instance with default allocator
using SetPosition_Request =
  actuator_msgs::srv::SetPosition_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace actuator_msgs


#ifndef _WIN32
# define DEPRECATED__actuator_msgs__srv__SetPosition_Response __attribute__((deprecated))
#else
# define DEPRECATED__actuator_msgs__srv__SetPosition_Response __declspec(deprecated)
#endif

namespace actuator_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct SetPosition_Response_
{
  using Type = SetPosition_Response_<ContainerAllocator>;

  explicit SetPosition_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->message = "";
    }
  }

  explicit SetPosition_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : message(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->message = "";
    }
  }

  // field types and members
  using _success_type =
    bool;
  _success_type success;
  using _message_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _message_type message;

  // setters for named parameter idiom
  Type & set__success(
    const bool & _arg)
  {
    this->success = _arg;
    return *this;
  }
  Type & set__message(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->message = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    actuator_msgs::srv::SetPosition_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const actuator_msgs::srv::SetPosition_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<actuator_msgs::srv::SetPosition_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<actuator_msgs::srv::SetPosition_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      actuator_msgs::srv::SetPosition_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<actuator_msgs::srv::SetPosition_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      actuator_msgs::srv::SetPosition_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<actuator_msgs::srv::SetPosition_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<actuator_msgs::srv::SetPosition_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<actuator_msgs::srv::SetPosition_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__actuator_msgs__srv__SetPosition_Response
    std::shared_ptr<actuator_msgs::srv::SetPosition_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__actuator_msgs__srv__SetPosition_Response
    std::shared_ptr<actuator_msgs::srv::SetPosition_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SetPosition_Response_ & other) const
  {
    if (this->success != other.success) {
      return false;
    }
    if (this->message != other.message) {
      return false;
    }
    return true;
  }
  bool operator!=(const SetPosition_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SetPosition_Response_

// alias to use template instance with default allocator
using SetPosition_Response =
  actuator_msgs::srv::SetPosition_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace actuator_msgs

namespace actuator_msgs
{

namespace srv
{

struct SetPosition
{
  using Request = actuator_msgs::srv::SetPosition_Request;
  using Response = actuator_msgs::srv::SetPosition_Response;
};

}  // namespace srv

}  // namespace actuator_msgs

#endif  // ACTUATOR_MSGS__SRV__DETAIL__SET_POSITION__STRUCT_HPP_
