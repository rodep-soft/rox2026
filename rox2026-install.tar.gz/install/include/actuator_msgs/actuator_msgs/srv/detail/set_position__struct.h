// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from actuator_msgs:srv/SetPosition.idl
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__SRV__DETAIL__SET_POSITION__STRUCT_H_
#define ACTUATOR_MSGS__SRV__DETAIL__SET_POSITION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in srv/SetPosition in the package actuator_msgs.
typedef struct actuator_msgs__srv__SetPosition_Request
{
  uint16_t logical_id;
  float position;
} actuator_msgs__srv__SetPosition_Request;

// Struct for a sequence of actuator_msgs__srv__SetPosition_Request.
typedef struct actuator_msgs__srv__SetPosition_Request__Sequence
{
  actuator_msgs__srv__SetPosition_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} actuator_msgs__srv__SetPosition_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/SetPosition in the package actuator_msgs.
typedef struct actuator_msgs__srv__SetPosition_Response
{
  bool success;
  rosidl_runtime_c__String message;
} actuator_msgs__srv__SetPosition_Response;

// Struct for a sequence of actuator_msgs__srv__SetPosition_Response.
typedef struct actuator_msgs__srv__SetPosition_Response__Sequence
{
  actuator_msgs__srv__SetPosition_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} actuator_msgs__srv__SetPosition_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ACTUATOR_MSGS__SRV__DETAIL__SET_POSITION__STRUCT_H_
