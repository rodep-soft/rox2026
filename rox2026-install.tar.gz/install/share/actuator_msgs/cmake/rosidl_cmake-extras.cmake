# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(actuator_msgs_IDL_FILES "msg/ActuatorTarget.idl;msg/ActuatorTargetArray.idl;msg/ActuatorState.idl;msg/ActuatorStateArray.idl;srv/SetPosition.idl")
set(actuator_msgs_INTERFACE_FILES "msg/ActuatorTarget.msg;msg/ActuatorTargetArray.msg;msg/ActuatorState.msg;msg/ActuatorStateArray.msg;srv/SetPosition.srv;srv/SetPosition_Request.msg;srv/SetPosition_Response.msg")
