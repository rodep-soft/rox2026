#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "actuator_msgs::actuator_msgs__rosidl_generator_py" for configuration "Release"
set_property(TARGET actuator_msgs::actuator_msgs__rosidl_generator_py APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(actuator_msgs::actuator_msgs__rosidl_generator_py PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libactuator_msgs__rosidl_generator_py.so"
  IMPORTED_SONAME_RELEASE "libactuator_msgs__rosidl_generator_py.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS actuator_msgs::actuator_msgs__rosidl_generator_py )
list(APPEND _IMPORT_CHECK_FILES_FOR_actuator_msgs::actuator_msgs__rosidl_generator_py "${_IMPORT_PREFIX}/lib/libactuator_msgs__rosidl_generator_py.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
