#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



// Corresponds to actuator_msgs__msg__ActuatorTarget

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ActuatorTarget {

    // This member is not documented.
    #[allow(missing_docs)]
    pub logical_id: u16,


    // This member is not documented.
    #[allow(missing_docs)]
    pub target: f32,

}



impl Default for ActuatorTarget {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ActuatorTarget::default())
  }
}

impl rosidl_runtime_rs::Message for ActuatorTarget {
  type RmwMsg = super::msg::rmw::ActuatorTarget;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        logical_id: msg.logical_id,
        target: msg.target,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      logical_id: msg.logical_id,
      target: msg.target,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      logical_id: msg.logical_id,
      target: msg.target,
    }
  }
}


// Corresponds to actuator_msgs__msg__ActuatorTargetArray

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ActuatorTargetArray {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub actuators: Vec<super::msg::ActuatorTarget>,

}



impl Default for ActuatorTargetArray {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ActuatorTargetArray::default())
  }
}

impl rosidl_runtime_rs::Message for ActuatorTargetArray {
  type RmwMsg = super::msg::rmw::ActuatorTargetArray;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        actuators: msg.actuators
          .into_iter()
          .map(|elem| super::msg::ActuatorTarget::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
        actuators: msg.actuators
          .iter()
          .map(|elem| super::msg::ActuatorTarget::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      actuators: msg.actuators
          .into_iter()
          .map(super::msg::ActuatorTarget::from_rmw_message)
          .collect(),
    }
  }
}


// Corresponds to actuator_msgs__msg__ActuatorState
/// ActuatorState.msg

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ActuatorState {

    // This member is not documented.
    #[allow(missing_docs)]
    pub logical_id: u16,


    // This member is not documented.
    #[allow(missing_docs)]
    pub state: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub position_reference_set: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub position: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub velocity: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub torque_nm: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub current_a: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub temperature: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub fault_code: u32,

}

impl ActuatorState {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_OFFLINE: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_INITIALIZING: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_READY: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_ERROR: u8 = 3;

}


impl Default for ActuatorState {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ActuatorState::default())
  }
}

impl rosidl_runtime_rs::Message for ActuatorState {
  type RmwMsg = super::msg::rmw::ActuatorState;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        logical_id: msg.logical_id,
        state: msg.state,
        position_reference_set: msg.position_reference_set,
        position: msg.position,
        velocity: msg.velocity,
        torque_nm: msg.torque_nm,
        current_a: msg.current_a,
        temperature: msg.temperature,
        fault_code: msg.fault_code,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      logical_id: msg.logical_id,
      state: msg.state,
      position_reference_set: msg.position_reference_set,
      position: msg.position,
      velocity: msg.velocity,
      torque_nm: msg.torque_nm,
      current_a: msg.current_a,
      temperature: msg.temperature,
      fault_code: msg.fault_code,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      logical_id: msg.logical_id,
      state: msg.state,
      position_reference_set: msg.position_reference_set,
      position: msg.position,
      velocity: msg.velocity,
      torque_nm: msg.torque_nm,
      current_a: msg.current_a,
      temperature: msg.temperature,
      fault_code: msg.fault_code,
    }
  }
}


// Corresponds to actuator_msgs__msg__ActuatorStateArray

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ActuatorStateArray {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub actuators: Vec<super::msg::ActuatorState>,

}



impl Default for ActuatorStateArray {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ActuatorStateArray::default())
  }
}

impl rosidl_runtime_rs::Message for ActuatorStateArray {
  type RmwMsg = super::msg::rmw::ActuatorStateArray;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        actuators: msg.actuators
          .into_iter()
          .map(|elem| super::msg::ActuatorState::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
        actuators: msg.actuators
          .iter()
          .map(|elem| super::msg::ActuatorState::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      actuators: msg.actuators
          .into_iter()
          .map(super::msg::ActuatorState::from_rmw_message)
          .collect(),
    }
  }
}


