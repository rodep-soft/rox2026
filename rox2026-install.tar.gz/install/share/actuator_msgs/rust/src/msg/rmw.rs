#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};


#[link(name = "actuator_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__actuator_msgs__msg__ActuatorTarget() -> *const std::ffi::c_void;
}

#[link(name = "actuator_msgs__rosidl_generator_c")]
extern "C" {
    fn actuator_msgs__msg__ActuatorTarget__init(msg: *mut ActuatorTarget) -> bool;
    fn actuator_msgs__msg__ActuatorTarget__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ActuatorTarget>, size: usize) -> bool;
    fn actuator_msgs__msg__ActuatorTarget__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ActuatorTarget>);
    fn actuator_msgs__msg__ActuatorTarget__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ActuatorTarget>, out_seq: *mut rosidl_runtime_rs::Sequence<ActuatorTarget>) -> bool;
}

// Corresponds to actuator_msgs__msg__ActuatorTarget
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ActuatorTarget {

    // This member is not documented.
    #[allow(missing_docs)]
    pub logical_id: u16,


    // This member is not documented.
    #[allow(missing_docs)]
    pub target: f32,

}



impl Default for ActuatorTarget {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !actuator_msgs__msg__ActuatorTarget__init(&mut msg as *mut _) {
        panic!("Call to actuator_msgs__msg__ActuatorTarget__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ActuatorTarget {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { actuator_msgs__msg__ActuatorTarget__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { actuator_msgs__msg__ActuatorTarget__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { actuator_msgs__msg__ActuatorTarget__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ActuatorTarget {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ActuatorTarget where Self: Sized {
  const TYPE_NAME: &'static str = "actuator_msgs/msg/ActuatorTarget";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__actuator_msgs__msg__ActuatorTarget() }
  }
}


#[link(name = "actuator_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__actuator_msgs__msg__ActuatorTargetArray() -> *const std::ffi::c_void;
}

#[link(name = "actuator_msgs__rosidl_generator_c")]
extern "C" {
    fn actuator_msgs__msg__ActuatorTargetArray__init(msg: *mut ActuatorTargetArray) -> bool;
    fn actuator_msgs__msg__ActuatorTargetArray__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ActuatorTargetArray>, size: usize) -> bool;
    fn actuator_msgs__msg__ActuatorTargetArray__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ActuatorTargetArray>);
    fn actuator_msgs__msg__ActuatorTargetArray__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ActuatorTargetArray>, out_seq: *mut rosidl_runtime_rs::Sequence<ActuatorTargetArray>) -> bool;
}

// Corresponds to actuator_msgs__msg__ActuatorTargetArray
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ActuatorTargetArray {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub actuators: rosidl_runtime_rs::Sequence<super::super::msg::rmw::ActuatorTarget>,

}



impl Default for ActuatorTargetArray {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !actuator_msgs__msg__ActuatorTargetArray__init(&mut msg as *mut _) {
        panic!("Call to actuator_msgs__msg__ActuatorTargetArray__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ActuatorTargetArray {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { actuator_msgs__msg__ActuatorTargetArray__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { actuator_msgs__msg__ActuatorTargetArray__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { actuator_msgs__msg__ActuatorTargetArray__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ActuatorTargetArray {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ActuatorTargetArray where Self: Sized {
  const TYPE_NAME: &'static str = "actuator_msgs/msg/ActuatorTargetArray";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__actuator_msgs__msg__ActuatorTargetArray() }
  }
}


#[link(name = "actuator_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__actuator_msgs__msg__ActuatorState() -> *const std::ffi::c_void;
}

#[link(name = "actuator_msgs__rosidl_generator_c")]
extern "C" {
    fn actuator_msgs__msg__ActuatorState__init(msg: *mut ActuatorState) -> bool;
    fn actuator_msgs__msg__ActuatorState__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ActuatorState>, size: usize) -> bool;
    fn actuator_msgs__msg__ActuatorState__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ActuatorState>);
    fn actuator_msgs__msg__ActuatorState__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ActuatorState>, out_seq: *mut rosidl_runtime_rs::Sequence<ActuatorState>) -> bool;
}

// Corresponds to actuator_msgs__msg__ActuatorState
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// ActuatorState.msg

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ActuatorState {

    // This member is not documented.
    #[allow(missing_docs)]
    pub logical_id: u16,


    // This member is not documented.
    #[allow(missing_docs)]
    pub state: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub position_reference_set: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub position: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub velocity: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub torque_nm: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub current_a: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub temperature: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub fault_code: u32,

}

impl ActuatorState {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_OFFLINE: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_INITIALIZING: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_READY: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_ERROR: u8 = 3;

}


impl Default for ActuatorState {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !actuator_msgs__msg__ActuatorState__init(&mut msg as *mut _) {
        panic!("Call to actuator_msgs__msg__ActuatorState__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ActuatorState {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { actuator_msgs__msg__ActuatorState__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { actuator_msgs__msg__ActuatorState__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { actuator_msgs__msg__ActuatorState__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ActuatorState {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ActuatorState where Self: Sized {
  const TYPE_NAME: &'static str = "actuator_msgs/msg/ActuatorState";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__actuator_msgs__msg__ActuatorState() }
  }
}


#[link(name = "actuator_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__actuator_msgs__msg__ActuatorStateArray() -> *const std::ffi::c_void;
}

#[link(name = "actuator_msgs__rosidl_generator_c")]
extern "C" {
    fn actuator_msgs__msg__ActuatorStateArray__init(msg: *mut ActuatorStateArray) -> bool;
    fn actuator_msgs__msg__ActuatorStateArray__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ActuatorStateArray>, size: usize) -> bool;
    fn actuator_msgs__msg__ActuatorStateArray__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ActuatorStateArray>);
    fn actuator_msgs__msg__ActuatorStateArray__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ActuatorStateArray>, out_seq: *mut rosidl_runtime_rs::Sequence<ActuatorStateArray>) -> bool;
}

// Corresponds to actuator_msgs__msg__ActuatorStateArray
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ActuatorStateArray {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub actuators: rosidl_runtime_rs::Sequence<super::super::msg::rmw::ActuatorState>,

}



impl Default for ActuatorStateArray {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !actuator_msgs__msg__ActuatorStateArray__init(&mut msg as *mut _) {
        panic!("Call to actuator_msgs__msg__ActuatorStateArray__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ActuatorStateArray {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { actuator_msgs__msg__ActuatorStateArray__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { actuator_msgs__msg__ActuatorStateArray__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { actuator_msgs__msg__ActuatorStateArray__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ActuatorStateArray {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ActuatorStateArray where Self: Sized {
  const TYPE_NAME: &'static str = "actuator_msgs/msg/ActuatorStateArray";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__actuator_msgs__msg__ActuatorStateArray() }
  }
}


