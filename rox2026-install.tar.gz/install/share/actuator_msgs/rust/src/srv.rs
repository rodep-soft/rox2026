#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};




// Corresponds to actuator_msgs__srv__SetPosition_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SetPosition_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub logical_id: u16,


    // This member is not documented.
    #[allow(missing_docs)]
    pub position: f32,

}



impl Default for SetPosition_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::SetPosition_Request::default())
  }
}

impl rosidl_runtime_rs::Message for SetPosition_Request {
  type RmwMsg = super::srv::rmw::SetPosition_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        logical_id: msg.logical_id,
        position: msg.position,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      logical_id: msg.logical_id,
      position: msg.position,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      logical_id: msg.logical_id,
      position: msg.position,
    }
  }
}


// Corresponds to actuator_msgs__srv__SetPosition_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SetPosition_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: std::string::String,

}



impl Default for SetPosition_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::SetPosition_Response::default())
  }
}

impl rosidl_runtime_rs::Message for SetPosition_Response {
  type RmwMsg = super::srv::rmw::SetPosition_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
    }
  }
}






#[link(name = "actuator_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__actuator_msgs__srv__SetPosition() -> *const std::ffi::c_void;
}

// Corresponds to actuator_msgs__srv__SetPosition
#[allow(missing_docs, non_camel_case_types)]
pub struct SetPosition;

impl rosidl_runtime_rs::Service for SetPosition {
    type Request = SetPosition_Request;
    type Response = SetPosition_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__actuator_msgs__srv__SetPosition() }
    }
}


