# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(robot_msgs_IDL_FILES "msg/BeltMode.idl;msg/ArmPosition.idl;msg/ShotCycleState.idl;msg/BeltStatus.idl;msg/Game2State.idl")
set(robot_msgs_INTERFACE_FILES "msg/BeltMode.msg;msg/ArmPosition.msg;msg/ShotCycleState.msg;msg/BeltStatus.msg;msg/Game2State.msg")
