#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};


#[link(name = "robot_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_msgs__msg__BeltMode() -> *const std::ffi::c_void;
}

#[link(name = "robot_msgs__rosidl_generator_c")]
extern "C" {
    fn robot_msgs__msg__BeltMode__init(msg: *mut BeltMode) -> bool;
    fn robot_msgs__msg__BeltMode__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<BeltMode>, size: usize) -> bool;
    fn robot_msgs__msg__BeltMode__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<BeltMode>);
    fn robot_msgs__msg__BeltMode__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<BeltMode>, out_seq: *mut rosidl_runtime_rs::Sequence<BeltMode>) -> bool;
}

// Corresponds to robot_msgs__msg__BeltMode
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// ベルト駆動モード定義

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct BeltMode {

    // This member is not documented.
    #[allow(missing_docs)]
    pub mode: u8,

}

impl BeltMode {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STOP: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const LEVEL_1: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const LEVEL_2: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const LEVEL_3: u8 = 3;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const LEVEL_4: u8 = 4;

}


impl Default for BeltMode {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_msgs__msg__BeltMode__init(&mut msg as *mut _) {
        panic!("Call to robot_msgs__msg__BeltMode__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for BeltMode {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_msgs__msg__BeltMode__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_msgs__msg__BeltMode__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_msgs__msg__BeltMode__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for BeltMode {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for BeltMode where Self: Sized {
  const TYPE_NAME: &'static str = "robot_msgs/msg/BeltMode";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_msgs__msg__BeltMode() }
  }
}


#[link(name = "robot_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_msgs__msg__ArmPosition() -> *const std::ffi::c_void;
}

#[link(name = "robot_msgs__rosidl_generator_c")]
extern "C" {
    fn robot_msgs__msg__ArmPosition__init(msg: *mut ArmPosition) -> bool;
    fn robot_msgs__msg__ArmPosition__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ArmPosition>, size: usize) -> bool;
    fn robot_msgs__msg__ArmPosition__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ArmPosition>);
    fn robot_msgs__msg__ArmPosition__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ArmPosition>, out_seq: *mut rosidl_runtime_rs::Sequence<ArmPosition>) -> bool;
}

// Corresponds to robot_msgs__msg__ArmPosition
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// ドリブルアーム姿勢定義

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ArmPosition {

    // This member is not documented.
    #[allow(missing_docs)]
    pub position: u8,

}

impl ArmPosition {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const DRIBBLE: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const OPEN: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const FEED: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const RECEIVE: u8 = 3;

}


impl Default for ArmPosition {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_msgs__msg__ArmPosition__init(&mut msg as *mut _) {
        panic!("Call to robot_msgs__msg__ArmPosition__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ArmPosition {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_msgs__msg__ArmPosition__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_msgs__msg__ArmPosition__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_msgs__msg__ArmPosition__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ArmPosition {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ArmPosition where Self: Sized {
  const TYPE_NAME: &'static str = "robot_msgs/msg/ArmPosition";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_msgs__msg__ArmPosition() }
  }
}


#[link(name = "robot_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_msgs__msg__ShotCycleState() -> *const std::ffi::c_void;
}

#[link(name = "robot_msgs__rosidl_generator_c")]
extern "C" {
    fn robot_msgs__msg__ShotCycleState__init(msg: *mut ShotCycleState) -> bool;
    fn robot_msgs__msg__ShotCycleState__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ShotCycleState>, size: usize) -> bool;
    fn robot_msgs__msg__ShotCycleState__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ShotCycleState>);
    fn robot_msgs__msg__ShotCycleState__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ShotCycleState>, out_seq: *mut rosidl_runtime_rs::Sequence<ShotCycleState>) -> bool;
}

// Corresponds to robot_msgs__msg__ShotCycleState
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// 自動シュートサイクル進行状態定義

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ShotCycleState {

    // This member is not documented.
    #[allow(missing_docs)]
    pub state: u8,

}

impl ShotCycleState {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const IDLE: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const BELT_SPINUP: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const OPENING: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const FEEDING: u8 = 3;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const RETURNING: u8 = 4;

}


impl Default for ShotCycleState {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_msgs__msg__ShotCycleState__init(&mut msg as *mut _) {
        panic!("Call to robot_msgs__msg__ShotCycleState__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ShotCycleState {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_msgs__msg__ShotCycleState__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_msgs__msg__ShotCycleState__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_msgs__msg__ShotCycleState__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ShotCycleState {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ShotCycleState where Self: Sized {
  const TYPE_NAME: &'static str = "robot_msgs/msg/ShotCycleState";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_msgs__msg__ShotCycleState() }
  }
}


#[link(name = "robot_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_msgs__msg__BeltStatus() -> *const std::ffi::c_void;
}

#[link(name = "robot_msgs__rosidl_generator_c")]
extern "C" {
    fn robot_msgs__msg__BeltStatus__init(msg: *mut BeltStatus) -> bool;
    fn robot_msgs__msg__BeltStatus__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<BeltStatus>, size: usize) -> bool;
    fn robot_msgs__msg__BeltStatus__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<BeltStatus>);
    fn robot_msgs__msg__BeltStatus__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<BeltStatus>, out_seq: *mut rosidl_runtime_rs::Sequence<BeltStatus>) -> bool;
}

// Corresponds to robot_msgs__msg__BeltStatus
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// 上下ベルトのRPM実測・目標状態（定量評価用）

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct BeltStatus {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub underbelt_target_rpm: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub underbelt_measured_rpm: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub upperbelt_target_rpm: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub upperbelt_measured_rpm: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub rpm_difference: f32,

}



impl Default for BeltStatus {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_msgs__msg__BeltStatus__init(&mut msg as *mut _) {
        panic!("Call to robot_msgs__msg__BeltStatus__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for BeltStatus {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_msgs__msg__BeltStatus__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_msgs__msg__BeltStatus__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_msgs__msg__BeltStatus__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for BeltStatus {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for BeltStatus where Self: Sized {
  const TYPE_NAME: &'static str = "robot_msgs/msg/BeltStatus";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_msgs__msg__BeltStatus() }
  }
}


#[link(name = "robot_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_msgs__msg__Game2State() -> *const std::ffi::c_void;
}

#[link(name = "robot_msgs__rosidl_generator_c")]
extern "C" {
    fn robot_msgs__msg__Game2State__init(msg: *mut Game2State) -> bool;
    fn robot_msgs__msg__Game2State__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Game2State>, size: usize) -> bool;
    fn robot_msgs__msg__Game2State__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Game2State>);
    fn robot_msgs__msg__Game2State__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Game2State>, out_seq: *mut rosidl_runtime_rs::Sequence<Game2State>) -> bool;
}

// Corresponds to robot_msgs__msg__Game2State
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// Game2 パネル戦術自動射出シーケンス状態

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Game2State {

    // This member is not documented.
    #[allow(missing_docs)]
    pub state: u8,

}

impl Game2State {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STANDBY: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const SEARCHING: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ALIGNING: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const PREPARING_SHOOT: u8 = 3;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const SHOOTING: u8 = 4;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const WAITING_RESULT: u8 = 5;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const COMPLETED: u8 = 6;

}


impl Default for Game2State {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_msgs__msg__Game2State__init(&mut msg as *mut _) {
        panic!("Call to robot_msgs__msg__Game2State__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Game2State {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_msgs__msg__Game2State__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_msgs__msg__Game2State__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_msgs__msg__Game2State__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Game2State {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Game2State where Self: Sized {
  const TYPE_NAME: &'static str = "robot_msgs/msg/Game2State";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_msgs__msg__Game2State() }
  }
}


