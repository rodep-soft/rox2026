#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



// Corresponds to robot_msgs__msg__BeltMode
/// ベルト駆動モード定義

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct BeltMode {

    // This member is not documented.
    #[allow(missing_docs)]
    pub mode: u8,

}

impl BeltMode {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STOP: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const LEVEL_1: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const LEVEL_2: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const LEVEL_3: u8 = 3;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const LEVEL_4: u8 = 4;

}


impl Default for BeltMode {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::BeltMode::default())
  }
}

impl rosidl_runtime_rs::Message for BeltMode {
  type RmwMsg = super::msg::rmw::BeltMode;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        mode: msg.mode,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      mode: msg.mode,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      mode: msg.mode,
    }
  }
}


// Corresponds to robot_msgs__msg__ArmPosition
/// ドリブルアーム姿勢定義

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ArmPosition {

    // This member is not documented.
    #[allow(missing_docs)]
    pub position: u8,

}

impl ArmPosition {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const DRIBBLE: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const OPEN: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const FEED: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const RECEIVE: u8 = 3;

}


impl Default for ArmPosition {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ArmPosition::default())
  }
}

impl rosidl_runtime_rs::Message for ArmPosition {
  type RmwMsg = super::msg::rmw::ArmPosition;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        position: msg.position,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      position: msg.position,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      position: msg.position,
    }
  }
}


// Corresponds to robot_msgs__msg__ShotCycleState
/// 自動シュートサイクル進行状態定義

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ShotCycleState {

    // This member is not documented.
    #[allow(missing_docs)]
    pub state: u8,

}

impl ShotCycleState {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const IDLE: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const BELT_SPINUP: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const OPENING: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const FEEDING: u8 = 3;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const RETURNING: u8 = 4;

}


impl Default for ShotCycleState {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ShotCycleState::default())
  }
}

impl rosidl_runtime_rs::Message for ShotCycleState {
  type RmwMsg = super::msg::rmw::ShotCycleState;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        state: msg.state,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      state: msg.state,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      state: msg.state,
    }
  }
}


// Corresponds to robot_msgs__msg__BeltStatus
/// 上下ベルトのRPM実測・目標状態（定量評価用）

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct BeltStatus {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub underbelt_target_rpm: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub underbelt_measured_rpm: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub upperbelt_target_rpm: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub upperbelt_measured_rpm: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub rpm_difference: f32,

}



impl Default for BeltStatus {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::BeltStatus::default())
  }
}

impl rosidl_runtime_rs::Message for BeltStatus {
  type RmwMsg = super::msg::rmw::BeltStatus;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        underbelt_target_rpm: msg.underbelt_target_rpm,
        underbelt_measured_rpm: msg.underbelt_measured_rpm,
        upperbelt_target_rpm: msg.upperbelt_target_rpm,
        upperbelt_measured_rpm: msg.upperbelt_measured_rpm,
        rpm_difference: msg.rpm_difference,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
      underbelt_target_rpm: msg.underbelt_target_rpm,
      underbelt_measured_rpm: msg.underbelt_measured_rpm,
      upperbelt_target_rpm: msg.upperbelt_target_rpm,
      upperbelt_measured_rpm: msg.upperbelt_measured_rpm,
      rpm_difference: msg.rpm_difference,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      underbelt_target_rpm: msg.underbelt_target_rpm,
      underbelt_measured_rpm: msg.underbelt_measured_rpm,
      upperbelt_target_rpm: msg.upperbelt_target_rpm,
      upperbelt_measured_rpm: msg.upperbelt_measured_rpm,
      rpm_difference: msg.rpm_difference,
    }
  }
}


// Corresponds to robot_msgs__msg__Game2State
/// Game2 パネル戦術自動射出シーケンス状態

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Game2State {

    // This member is not documented.
    #[allow(missing_docs)]
    pub state: u8,

}

impl Game2State {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STANDBY: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const SEARCHING: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ALIGNING: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const PREPARING_SHOOT: u8 = 3;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const SHOOTING: u8 = 4;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const WAITING_RESULT: u8 = 5;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const COMPLETED: u8 = 6;

}


impl Default for Game2State {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Game2State::default())
  }
}

impl rosidl_runtime_rs::Message for Game2State {
  type RmwMsg = super::msg::rmw::Game2State;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        state: msg.state,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      state: msg.state,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      state: msg.state,
    }
  }
}


