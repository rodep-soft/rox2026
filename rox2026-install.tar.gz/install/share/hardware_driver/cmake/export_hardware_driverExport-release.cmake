#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "hardware_driver::stm32_protocol" for configuration "Release"
set_property(TARGET hardware_driver::stm32_protocol APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hardware_driver::stm32_protocol PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libstm32_protocol.a"
  )

list(APPEND _IMPORT_CHECK_TARGETS hardware_driver::stm32_protocol )
list(APPEND _IMPORT_CHECK_FILES_FOR_hardware_driver::stm32_protocol "${_IMPORT_PREFIX}/lib/libstm32_protocol.a" )

# Import target "hardware_driver::edulite05_protocol" for configuration "Release"
set_property(TARGET hardware_driver::edulite05_protocol APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hardware_driver::edulite05_protocol PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libedulite05_protocol.a"
  )

list(APPEND _IMPORT_CHECK_TARGETS hardware_driver::edulite05_protocol )
list(APPEND _IMPORT_CHECK_FILES_FOR_hardware_driver::edulite05_protocol "${_IMPORT_PREFIX}/lib/libedulite05_protocol.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
