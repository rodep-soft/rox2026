# generated from ament/cmake/core/templates/nameConfig.cmake.in

# prevent multiple inclusion
if(_zenoh_joy_rs_CONFIG_INCLUDED)
  # ensure to keep the found flag the same
  if(NOT DEFINED zenoh_joy_rs_FOUND)
    # explicitly set it to FALSE, otherwise CMake will set it to TRUE
    set(zenoh_joy_rs_FOUND FALSE)
  elseif(NOT zenoh_joy_rs_FOUND)
    # use separate condition to avoid uninitialized variable warning
    set(zenoh_joy_rs_FOUND FALSE)
  endif()
  return()
endif()
set(_zenoh_joy_rs_CONFIG_INCLUDED TRUE)

# output package information
if(NOT zenoh_joy_rs_FIND_QUIETLY)
  message(STATUS "Found zenoh_joy_rs: 0.2.0 (${zenoh_joy_rs_DIR})")
endif()

# warn when using a deprecated package
if(NOT "" STREQUAL "")
  set(_msg "Package 'zenoh_joy_rs' is deprecated")
  # append custom deprecation text if available
  if(NOT "" STREQUAL "TRUE")
    set(_msg "${_msg} ()")
  endif()
  # optionally quiet the deprecation message
  if(NOT ${zenoh_joy_rs_DEPRECATED_QUIET})
    message(DEPRECATION "${_msg}")
  endif()
endif()

# flag package as ament-based to distinguish it after being find_package()-ed
set(zenoh_joy_rs_FOUND_AMENT_PACKAGE TRUE)

# include all config extra files
set(_extras "")
foreach(_extra ${_extras})
  include("${zenoh_joy_rs_DIR}/${_extra}")
endforeach()
