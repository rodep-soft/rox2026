# generated from rosidl_cmake/cmake/rosidl_cmake_aggregate_target-extras.cmake.in

# Create a convenience aggregate target ros2_socketcan_msgs::ros2_socketcan_msgs
# that links all generated interface targets, so downstream packages can use
# a single modern CMake target name instead of ${ros2_socketcan_msgs_TARGETS}.
if(ros2_socketcan_msgs_TARGETS AND NOT TARGET ros2_socketcan_msgs::ros2_socketcan_msgs)
  add_library(ros2_socketcan_msgs::ros2_socketcan_msgs INTERFACE IMPORTED)
  set_target_properties(ros2_socketcan_msgs::ros2_socketcan_msgs PROPERTIES
    INTERFACE_LINK_LIBRARIES "${ros2_socketcan_msgs_TARGETS}")
endif()
