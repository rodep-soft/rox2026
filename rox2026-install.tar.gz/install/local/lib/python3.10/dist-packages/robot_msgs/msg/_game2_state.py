# generated from rosidl_generator_py/resource/_idl.py.em
# with input from robot_msgs:msg/Game2State.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_Game2State(type):
    """Metaclass of message 'Game2State'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'STANDBY': 0,
        'SEARCHING': 1,
        'ALIGNING': 2,
        'PREPARING_SHOOT': 3,
        'SHOOTING': 4,
        'WAITING_RESULT': 5,
        'COMPLETED': 6,
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('robot_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'robot_msgs.msg.Game2State')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__game2_state
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__game2_state
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__game2_state
            cls._TYPE_SUPPORT = module.type_support_msg__msg__game2_state
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__game2_state

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'STANDBY': cls.__constants['STANDBY'],
            'SEARCHING': cls.__constants['SEARCHING'],
            'ALIGNING': cls.__constants['ALIGNING'],
            'PREPARING_SHOOT': cls.__constants['PREPARING_SHOOT'],
            'SHOOTING': cls.__constants['SHOOTING'],
            'WAITING_RESULT': cls.__constants['WAITING_RESULT'],
            'COMPLETED': cls.__constants['COMPLETED'],
        }

    @property
    def STANDBY(self):
        """Message constant 'STANDBY'."""
        return Metaclass_Game2State.__constants['STANDBY']

    @property
    def SEARCHING(self):
        """Message constant 'SEARCHING'."""
        return Metaclass_Game2State.__constants['SEARCHING']

    @property
    def ALIGNING(self):
        """Message constant 'ALIGNING'."""
        return Metaclass_Game2State.__constants['ALIGNING']

    @property
    def PREPARING_SHOOT(self):
        """Message constant 'PREPARING_SHOOT'."""
        return Metaclass_Game2State.__constants['PREPARING_SHOOT']

    @property
    def SHOOTING(self):
        """Message constant 'SHOOTING'."""
        return Metaclass_Game2State.__constants['SHOOTING']

    @property
    def WAITING_RESULT(self):
        """Message constant 'WAITING_RESULT'."""
        return Metaclass_Game2State.__constants['WAITING_RESULT']

    @property
    def COMPLETED(self):
        """Message constant 'COMPLETED'."""
        return Metaclass_Game2State.__constants['COMPLETED']


class Game2State(metaclass=Metaclass_Game2State):
    """
    Message class 'Game2State'.

    Constants:
      STANDBY
      SEARCHING
      ALIGNING
      PREPARING_SHOOT
      SHOOTING
      WAITING_RESULT
      COMPLETED
    """

    __slots__ = [
        '_state',
    ]

    _fields_and_field_types = {
        'state': 'uint8',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.state = kwargs.get('state', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.state != other.state:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def state(self):
        """Message field 'state'."""
        return self._state

    @state.setter
    def state(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'state' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'state' field must be an unsigned integer in [0, 255]"
        self._state = value
