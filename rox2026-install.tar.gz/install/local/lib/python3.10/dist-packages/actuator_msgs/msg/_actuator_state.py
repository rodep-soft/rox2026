# generated from rosidl_generator_py/resource/_idl.py.em
# with input from actuator_msgs:msg/ActuatorState.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_ActuatorState(type):
    """Metaclass of message 'ActuatorState'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'STATE_OFFLINE': 0,
        'STATE_INITIALIZING': 1,
        'STATE_READY': 2,
        'STATE_ERROR': 3,
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('actuator_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'actuator_msgs.msg.ActuatorState')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__actuator_state
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__actuator_state
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__actuator_state
            cls._TYPE_SUPPORT = module.type_support_msg__msg__actuator_state
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__actuator_state

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'STATE_OFFLINE': cls.__constants['STATE_OFFLINE'],
            'STATE_INITIALIZING': cls.__constants['STATE_INITIALIZING'],
            'STATE_READY': cls.__constants['STATE_READY'],
            'STATE_ERROR': cls.__constants['STATE_ERROR'],
        }

    @property
    def STATE_OFFLINE(self):
        """Message constant 'STATE_OFFLINE'."""
        return Metaclass_ActuatorState.__constants['STATE_OFFLINE']

    @property
    def STATE_INITIALIZING(self):
        """Message constant 'STATE_INITIALIZING'."""
        return Metaclass_ActuatorState.__constants['STATE_INITIALIZING']

    @property
    def STATE_READY(self):
        """Message constant 'STATE_READY'."""
        return Metaclass_ActuatorState.__constants['STATE_READY']

    @property
    def STATE_ERROR(self):
        """Message constant 'STATE_ERROR'."""
        return Metaclass_ActuatorState.__constants['STATE_ERROR']


class ActuatorState(metaclass=Metaclass_ActuatorState):
    """
    Message class 'ActuatorState'.

    Constants:
      STATE_OFFLINE
      STATE_INITIALIZING
      STATE_READY
      STATE_ERROR
    """

    __slots__ = [
        '_logical_id',
        '_state',
        '_position_reference_set',
        '_position',
        '_velocity',
        '_torque_nm',
        '_current_a',
        '_temperature',
        '_fault_code',
    ]

    _fields_and_field_types = {
        'logical_id': 'uint16',
        'state': 'uint8',
        'position_reference_set': 'boolean',
        'position': 'float',
        'velocity': 'float',
        'torque_nm': 'float',
        'current_a': 'float',
        'temperature': 'float',
        'fault_code': 'uint32',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('uint16'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.logical_id = kwargs.get('logical_id', int())
        self.state = kwargs.get('state', int())
        self.position_reference_set = kwargs.get('position_reference_set', bool())
        self.position = kwargs.get('position', float())
        self.velocity = kwargs.get('velocity', float())
        self.torque_nm = kwargs.get('torque_nm', float())
        self.current_a = kwargs.get('current_a', float())
        self.temperature = kwargs.get('temperature', float())
        self.fault_code = kwargs.get('fault_code', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.logical_id != other.logical_id:
            return False
        if self.state != other.state:
            return False
        if self.position_reference_set != other.position_reference_set:
            return False
        if self.position != other.position:
            return False
        if self.velocity != other.velocity:
            return False
        if self.torque_nm != other.torque_nm:
            return False
        if self.current_a != other.current_a:
            return False
        if self.temperature != other.temperature:
            return False
        if self.fault_code != other.fault_code:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def logical_id(self):
        """Message field 'logical_id'."""
        return self._logical_id

    @logical_id.setter
    def logical_id(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'logical_id' field must be of type 'int'"
            assert value >= 0 and value < 65536, \
                "The 'logical_id' field must be an unsigned integer in [0, 65535]"
        self._logical_id = value

    @builtins.property
    def state(self):
        """Message field 'state'."""
        return self._state

    @state.setter
    def state(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'state' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'state' field must be an unsigned integer in [0, 255]"
        self._state = value

    @builtins.property
    def position_reference_set(self):
        """Message field 'position_reference_set'."""
        return self._position_reference_set

    @position_reference_set.setter
    def position_reference_set(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'position_reference_set' field must be of type 'bool'"
        self._position_reference_set = value

    @builtins.property
    def position(self):
        """Message field 'position'."""
        return self._position

    @position.setter
    def position(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'position' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'position' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._position = value

    @builtins.property
    def velocity(self):
        """Message field 'velocity'."""
        return self._velocity

    @velocity.setter
    def velocity(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'velocity' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'velocity' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._velocity = value

    @builtins.property
    def torque_nm(self):
        """Message field 'torque_nm'."""
        return self._torque_nm

    @torque_nm.setter
    def torque_nm(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'torque_nm' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'torque_nm' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._torque_nm = value

    @builtins.property
    def current_a(self):
        """Message field 'current_a'."""
        return self._current_a

    @current_a.setter
    def current_a(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'current_a' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'current_a' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._current_a = value

    @builtins.property
    def temperature(self):
        """Message field 'temperature'."""
        return self._temperature

    @temperature.setter
    def temperature(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'temperature' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'temperature' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._temperature = value

    @builtins.property
    def fault_code(self):
        """Message field 'fault_code'."""
        return self._fault_code

    @fault_code.setter
    def fault_code(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'fault_code' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'fault_code' field must be an unsigned integer in [0, 4294967295]"
        self._fault_code = value
